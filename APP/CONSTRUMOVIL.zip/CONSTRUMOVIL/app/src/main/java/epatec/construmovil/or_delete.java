package epatec.construmovil;

import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.ConnectivityManager;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/6/2016.
 */

public class or_delete extends Fragment {
    View _myView;
    EditText _searchProductParam;
    Button _deleteSearch;
    ListView _ordersDelete;

    List<String> _showOrders,_ordersDate;
    List<Integer> _ordersID;

    Integer _wID = 0;

    String _toSync = "";

    DBManager _database;
    ConnectivityManager _connectionManager;

    ArrayAdapter<String> _orderAdapter;
    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.or_delete,null);
        _searchProductParam = (EditText) _myView.findViewById(R.id._searchProductParam);
        _wID = getArguments().getInt("W_ID",0);
        _deleteSearch = (Button) _myView.findViewById(R.id._deleteSearch);
        _ordersDelete = (ListView) _myView.findViewById(R.id._ordersDelete);
        _connectionManager = (ConnectivityManager)getContext().getSystemService(CONNECTIVITY_SERVICE);
        _database = new DBManager(getContext());
        _toSync = getString(R.string.server_url)+"api/order/delete/O_ID,C_ID/";
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                _deleteSearch.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (_searchProductParam.getText().toString().matches("")){
                            Snackbar.make(v,"You must enter some parameter",Snackbar.LENGTH_LONG).show();
                        }else{
                            loadOrder(_searchProductParam.getText().toString());
                            if (_showOrders.size()==0){
                                Snackbar.make(v,"There isn't any order that matches your request",Snackbar.LENGTH_LONG).show();
                                _searchProductParam.setText("");
                            }
                        }
                    }
                });

                _ordersDelete.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                        AlertDialog.Builder _builder = new AlertDialog.Builder(getContext());
                        _builder.setTitle("Delete this order?");
                        _builder.setIcon(R.drawable.ic_delete_black_24dp);
                        _builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                deleteOrder(_ordersID.get(position));
                                String _queue = _toSync+_ordersID.get(position)+","+_wID;
                                DataSync.getInstance(_connectionManager,_wID,getContext()).get_syncData().add(_queue);
                            }
                        })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                }).show();
                    }
                });
            }
        });

        return _myView;
    }

    /**
     * Elimina una orden usando como condición
     * de eliminado el ID de la orden
     * @param _orderID
     */
    public void deleteOrder(Integer _orderID){

        System.out.println("EL ORDEN ID ES:"+_orderID);
        String _query1 = "DELETE FROM ORDERXPRODUCT WHERE O_ID="+_orderID;
        String _query2 = "DELETE FROM EORDER WHERE O_ID="+_orderID;
        try {

            _database.deleteData(_query1);
            _database.deleteData(_query2);
        }catch (SQLiteException e){
            Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Carga las ordenes que tienen el producto
     * asociado
     * @param _search
     */
    private void loadOrder(String _search){
        String _query = "SELECT DISTINCT EOR.O_ID,EOR.O_Date " +
                "FROM EORDER AS EOR LEFT OUTER JOIN ORDERXPRODUCT AS OXP ON (EOR.O_ID = OXP.O_ID) " +
                "WHERE OXP.PR_Name LIKE '%"+_search+"%';";
        _showOrders = new ArrayList<>();
        _ordersID = new ArrayList<>();
        _ordersDate = new ArrayList<>();
        try {
            Cursor _cursor = _database.selectData(_query);
            System.out.println("EL TOTAL DE ORDENES ES: "+_cursor.getCount());
            if (_cursor.moveToFirst()) {
                do {
                    _showOrders.add("Order: " + _cursor.getInt(0));
                    _ordersDate.add(_cursor.getString(1));
                    _ordersID.add(_cursor.getInt(0));
                } while (_cursor.moveToNext());
            }
            _orderAdapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_activated_1, _showOrders);
            _ordersDelete.setAdapter(_orderAdapter);
            _orderAdapter.notifyDataSetChanged();
        }catch (SQLiteException e){
            Snackbar.make(_myView,"There has been an error with the Database. Try again",Snackbar.LENGTH_LONG).show();
        }

    }
}

