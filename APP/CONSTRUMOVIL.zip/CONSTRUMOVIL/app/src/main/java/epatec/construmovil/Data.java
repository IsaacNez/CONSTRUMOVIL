package epatec.construmovil;

/**
 * Created by Isaac on 11/17/2016.
 */

public class Data {
    private static Data _instance = null;

    /**
     * Clase estado Singleton
     *
     * @return Data si la instancia es diferente de null
     */
    public static Data getInstance(){
        if (_instance ==null){
            _instance = new Data();
        }
        return _instance;
    }

    /**
     * devuelve el ultimo insert que se ha hecho
     * @return
     */
    public String get_lastinsert() {
        return _lastinsert;
    }

    /**
     * Setea la acción actual de insert
     * @param _lastinsert
     */
    public void set_lastinsert(String _lastinsert) {
        this._lastinsert = _lastinsert;
    }

    private String _lastinsert = "";
}
