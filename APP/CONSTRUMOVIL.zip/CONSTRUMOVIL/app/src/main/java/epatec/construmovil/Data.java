package epatec.construmovil;

/**
 * Created by Isaac on 11/17/2016.
 */

public class Data {
    private static Data _instance = null;

    public static Data getInstance(){
        if (_instance ==null){
            _instance = new Data();
        }
        return _instance;
    }
    public String get_lastinsert() {
        return _lastinsert;
    }

    public void set_lastinsert(String _lastinsert) {
        this._lastinsert = _lastinsert;
    }

    private String _lastinsert = "";
}
