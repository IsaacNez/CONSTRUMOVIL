package epatec.construmovil;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class user_login extends AppCompatActivity {
    EditText _sellerID;
    EditText _sellerPassword;
    Button _sellerLog;
    ConnectivityManager _connectMng;

    String _sellerName ="";
    Integer _sellerUID =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        _sellerID = (EditText) findViewById(R.id._sellerID);
        _sellerPassword = (EditText) findViewById(R.id._sellerpassword);
        _sellerLog = (Button) findViewById(R.id._sellerLog);
        toolbar.setTitle("Login to ConstruMovil");
        setSupportActionBar(toolbar);
        _connectMng = (ConnectivityManager) getApplicationContext().getSystemService(CONNECTIVITY_SERVICE);

        _sellerLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                NetworkInfo _netInfo = _connectMng.getActiveNetworkInfo();
                if (_sellerID.getText().toString().matches("")) {
                    Snackbar.make(v, "You must provide your ID", Snackbar.LENGTH_LONG).show();
                }
                if (_sellerPassword.toString().matches(""))
                    Snackbar.make(v, "You must provide your Password", Snackbar.LENGTH_LONG).show();
                if (_netInfo == null | !_netInfo.isAvailable())
                    Snackbar.make(v, "You´re not connected to internet", Snackbar.LENGTH_LONG).show();
                else{

                    String _server = getString(R.string.server_url)+"/api/user/get/"+_sellerID.getText().toString()+"/"+_sellerPassword.getText().toString();
                    AsyncHttpClient httpClient = new AsyncHttpClient();
                    httpClient.get(getApplicationContext(),_server,new JsonHttpResponseHandler(){
                        /**
                         * Returns when request failed
                         *
                         * @param statusCode    http response status line
                         * @param headers       response headers if any
                         * @param throwable     throwable describing the way request failed
                         * @param errorResponse parsed response if any
                         */
                        @Override
                        public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                            Snackbar.make(v,throwable.getMessage(),Snackbar.LENGTH_LONG).show();
                            Intent _newIntent = new Intent(user_login.this,SellerActivity.class);
                            startActivity(_newIntent);
                        }

                        /**
                         * Returns when request succeeds
                         *
                         * @param statusCode http response status line
                         * @param headers    response headers if any
                         * @param response   parsed response if any
                         */
                        @Override
                        public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                            if (response.length() == 0){
                                Snackbar.make(v, "You are not authorized to login",Snackbar.LENGTH_LONG).show();
                            }else{
                                try {
                                    JSONObject _jsonresponse = response.getJSONObject(0);
                                    _sellerUID = _jsonresponse.getInt("W_ID");
                                    _sellerName = _jsonresponse.getString("W_Name");
                                    JSONArray _roles = _jsonresponse.getJSONArray("Roles");
                                    for(int i = 0; i < _roles.length(); i++){
                                        if (_roles.getInt(i) == 4){
                                            Intent _newIntent = new Intent(user_login.this,SellerActivity.class);
                                            _newIntent.putExtra("W_ID",_sellerUID);
                                            _newIntent.putExtra("W_Name",_sellerName);
                                            startActivity(_newIntent);
                                        }
                                    }
                                    Snackbar.make(v, "You are not authorized to login. Try again",Snackbar.LENGTH_LONG).show();
                                    _sellerID.setText("");
                                    _sellerPassword.setText("");

                                }catch (JSONException e){
                                    Snackbar.make(v,e.getLocalizedMessage(),Snackbar.LENGTH_LONG).show();
                                }
                            }

                        }
                    });
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_user_login, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
