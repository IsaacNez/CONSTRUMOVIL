package epatec.construmovil;

/**
 * Created by Isaac on 11/7/2016.
 */

public class DBConstants {
    public static final String CREATE_ORDER =
            "CREATE TABLE EORDER (" +
                    "O_ID INTEGER PRIMARY KEY," +
                    "O_Priority INTEGER NOT NULL," +
                    "O_Status TEXT NOT NULL," +
                    "O_Date DATETIME DEFAULT CURRENT_TIMESTAMP," +
                    "O_PPhone INTEGER NOT NULL," +
                    "S_ID INTEGER NOT NULL," +
                    "C_ID INTEGER NOT NULL," +
                    "W_ID INTEGER NOT NULL," +
                    "FOREIGN KEY (S_ID) REFERENCES SUCURSAL(S_ID)," +
                    "FOREIGN KEY (C_ID) REFERENCES CLIENT(C_ID),"+
                    "FOREIGN KEY (W_ID) REFERENCES WORKER(W_ID));";
    public static final String CREATE_CLIENT =
            "CREATE TABLE CLIENT (" +
                    "C_ID INTEGER PRIMARY KEY," +
                    "C_Name TEXT NOT NULL," +
                    "C_LName TEXT NOT NULL," +
                    "C_Address TEXT NOT NULL," +
                    "C_Phone INTEGER NOT NULL," +
                    "C_Date DATETIME NOT NULL," +
                    "C_Penalization INTEGER NOT NULL DEFAULT 0);";
    public static final String CREATE_PRODUCT =
            "CREATE TABLE PRODUCT (" +
                    "PR_ID INTEGER PRIMARY KEY," +
                    "PR_Name TEXT NOT NULL," +
                    "PR_Price INTEGER NOT NULL," +
                    "PR_Exempt INTEGER NOT NULL," +
                    "PR_Description TEXT NOT NULL," +
                    "PR_Quantity INTEGER NOT NULL," +
                    "S_ID INTEGER NOT NULL," +
                    "P_ID INTEGER NOT NULL," +
                    "FOREIGN KEY (S_ID) REFERENCES SUCURSAL(S_ID)," +
                    "FOREIGN KEY (P_ID) REFERENCES PROVIDER(P_ID));";
    public static final String CREATE_PROVIDER =
            "CREATE TABLE PROVIDER (" +
                    "P_ID INTEGER PRIMARY KEY," +
                    "P_Name TEXT NOT NULL," +
                    "P_LName TEXT NOT NULL," +
                    "P_Address TEXT NOT NULL," +
                    "P_Phone INTEGER NOT NULL," +
                    "P_Date DATETIME NOT NULL);";
    public static final String CREATE_CATEGORY =
            "CREATE TABLE CATEGORY(" +
                    "CA_ID TEXT PRIMARY KEY," +
                    "CA_Description TEXT NOT NULL);";
    public static final String CREATE_WORKER =
            "CREATE TABLE WORKER (" +
                    "W_ID INTEGER PRIMARY KEY," +
                    "W_Name TEXT NOT NULL," +
                    "W_LName TEXT NOT NULL," +
                    "W_Address TEXT NOT NULL);";
    public static final String CREATE_SUCURSAL =
            "CREATE TABLE SUCURSAL (" +
                    "S_ID INTEGER PRIMARY KEY," +
                    "S_Name TEXT NOT NULL," +
                    "S_Address TEXT NOT NULL);";
    public static final String CREATE_CXP =
            "CREATE TABLE CATEXPRODUCT (" +
                    "CXP_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "CA_ID TEXT NOT NULL," +
                    "PR_ID INTEGER NOT NULL," +
                    "FOREIGN KEY (CA_ID) REFERENCES CATEGORY(CA_ID)," +
                    "FOREIGN KEY (PR_ID) REFERENCES PRODUCT(PR_ID));";
    public static final String CREATE_OXP =
            "CREATE TABLE ORDERXPRODUCT (" +
                    "OXP_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "O_ID INTEGER NOT NULL," +
                    "PR_Name TEXT NOT NULL," +
                    "PR_Amount INTEGER NOT NULL," +
                    "PR_Price INTEGER NOT NULL," +
                    "FOREIGN KEY (O_ID) REFERENCES EORDER(O_ID));";

}
