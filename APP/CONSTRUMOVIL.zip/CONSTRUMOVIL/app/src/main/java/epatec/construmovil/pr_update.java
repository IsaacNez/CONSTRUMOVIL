package epatec.construmovil;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Isaac on 11/6/2016.
 */

public class pr_update extends Fragment {
    View _myView;
    Spinner _productUpdate;
    EditText _productNameUpdate, _productDescriptionUpdate, _quantityUpdate;
    CheckBox _yesUpdate;
    Button _updateButton;

    List<String> _productNameSpinner = new ArrayList<>();
    List<JSONObject> _products = new ArrayList<>();

    Integer _productSelected = 0;


    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.pr_update,null);
        loadProducts();
        _productUpdate = (Spinner) _myView.findViewById(R.id._productUpdate);
        _productNameUpdate = (EditText) _myView.findViewById(R.id._productNameUpdate);
        _productDescriptionUpdate = (EditText) _myView.findViewById(R.id._productDescriptionUpdate);
        _quantityUpdate = (EditText) _myView.findViewById(R.id._quantityUpdate);
        _yesUpdate = (CheckBox) _myView.findViewById(R.id._yesUpdate);
        _updateButton = (Button) _myView.findViewById(R.id._updateButton);

        ArrayAdapter<String> _productUpdateAdapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_productNameSpinner);
        _productUpdate.setAdapter(_productUpdateAdapter);

        _productUpdate.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                _productSelected = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        return _myView;
    }
    private void loadProducts(){
        //Here must do some shit
    }
}
