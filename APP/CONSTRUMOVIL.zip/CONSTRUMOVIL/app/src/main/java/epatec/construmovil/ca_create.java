package epatec.construmovil;

import android.database.sqlite.SQLiteException;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/13/2016.
 */

public class ca_create extends Fragment {
    View _myView;

    EditText _cateName,_cateDescription;
    Button _cateRegister;

    DBManager _database;
    ConnectivityManager _connectionManager;

    String _toSync = "";
    Integer _wID = 0;

    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.ca_create,null);
        _wID = getArguments().getInt("W_ID",0);
        _cateName = (EditText) _myView.findViewById(R.id._cateName);
        _cateDescription = (EditText) _myView.findViewById(R.id._cateDescription);
        _cateRegister = (Button) _myView.findViewById(R.id._cateRegister);
        _database = new DBManager(getContext());
        _toSync = getString(R.string.server_url)+"api/category/post@";
        _connectionManager = (ConnectivityManager)getContext().getSystemService(CONNECTIVITY_SERVICE);

        _cateRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (_cateName.getText().toString().matches("") | _cateDescription.getText().toString().matches(""))
                    Snackbar.make(v,"The name or description space is empty",Snackbar.LENGTH_LONG).show();
                else{

                    try{
                        String _caname = _cateName.getText().toString();
                        String _cadesc = _cateDescription.getText().toString();
                        JSONObject params = new JSONObject();
                        params.put("CA_ID",_caname);
                        params.put("CA_Description",_cadesc);
                        params.put("CA_Status","Available");
                        params.put("ID_Seller",_wID);
                        insert(params);
                        String _tmp = _toSync + params.toString();
                        DataSync.getInstance(_connectionManager, _wID,getContext()).get_syncData().add(_tmp);
                        _cateName.setText("");
                        _cateDescription.setText("");
                        Snackbar.make(v,"You have succesfully created a Category",Snackbar.LENGTH_LONG).show();
                    }catch (JSONException e){
                        e.printStackTrace();
                    }

                }
            }
        });
        return _myView;
    }

    /**
     * Inserta una categoría a la base de datos
     * @param params
     */
    public void insert(JSONObject params){
        try {
            String _query = "INSERT INTO CATEGORY VALUES('" +
                    params.getString("CA_ID") + "','" +
                    params.getString("CA_Description") + "','Available');";
            _database.insertData(_query);
        }catch (JSONException e){
            e.printStackTrace();
        }catch (SQLiteException e){
            Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
}
