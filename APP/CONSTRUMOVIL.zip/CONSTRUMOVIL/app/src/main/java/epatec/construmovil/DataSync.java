package epatec.construmovil;

import android.app.Activity;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Looper;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.SyncHttpClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/13/2016.
 */

public class DataSync extends Activity{
    private static DataSync _instance = null;
    private ConnectivityManager _connectionManager;
    private List<String> _syncData = new ArrayList<>();
    private DBManager _database = new DBManager(getBaseContext());
    private Integer _idSeller = 0;

    public List<String> get_syncData() {
        return _syncData;
    }

    private DataSync(ConnectivityManager pconnectionManager, Integer pIDSeller){
        _idSeller = pIDSeller;
        _connectionManager = pconnectionManager;
        startThread();
    }
    public static DataSync getInstance(ConnectivityManager pconnectionManager, Integer pIDSeller){
        if(_instance == null){
            _instance = new DataSync(pconnectionManager,pIDSeller);
        }
        return _instance;
    }
    public synchronized void startThread(){
        Thread _syncThread = new Thread(new Runnable() {
            @Override
            public void run() {
                NetworkInfo _info = _connectionManager.getActiveNetworkInfo();
                Looper.prepare();
                while(_info.isAvailable()) {
                    try {
                        //AskInfo();
                        Sync();
                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    try {
                        Thread.sleep(5000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        _syncThread.start();
    }
    public void AskInfo(){

        String server = "http://bryan:7580/api/sync/get/algo/"+_idSeller;
        SyncHttpClient httpClient = new SyncHttpClient();
        httpClient.get(getBaseContext(),server,new JsonHttpResponseHandler(){
            /**
             * Returns when request failed
             *
             * @param statusCode    http response status line
             * @param headers       response headers if any
             * @param throwable     throwable describing the way request failed
             * @param errorResponse parsed response if any
             */
            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONArray errorResponse) {
                Toast.makeText(getBaseContext(),"There has been a sync error",Toast.LENGTH_LONG).show();
            }

            /**
             * Returns when request succeeds
             *
             * @param statusCode http response status line
             * @param headers    response headers if any
             * @param response   parsed response if any
             */
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {
                try {
                    for (int i = 0 ; i < response.length(); i++){
                        JSONObject _newObject = response.getJSONObject(i);
                        if (_newObject.getString("action").matches("insert")){
                            JSONObject tmp = _newObject.getJSONObject("model");
                            if (_newObject.getString("table").matches("CLIENT")){
                                cl_create cl_create = new cl_create();
                                cl_create.insertClient(tmp);
                            }else if (_newObject.getString("table").matches("WORKER")){
                                String _query = "INSERT INTO WORKER VALUES(" +
                                        tmp.getInt("W_ID")+",'" +
                                        tmp.getString("W_Name")+"','" +
                                        tmp.getString("W_LName")+"','" +
                                        tmp.getString("W_Address")+"','" +
                                        tmp.getString("W_Password")+"','" +
                                        tmp.getString("W_Status")+"');";
                                _database.insertData(_query);

                            }else if (_newObject.getString("table").matches("EORDER")){
                                or_create or_create = new or_create();
                                or_create.insertOrder(tmp);
                            }else if (_newObject.getString("table").matches("PRODUCT")){
                                pr_create pr_create = new pr_create();
                                pr_create.insertProduct(tmp);
                            }else if (_newObject.getString("table").matches("PROVIDER")){
                                p_create p_create =  new p_create();
                                p_create.insertData(tmp);
                            }else if (_newObject.getString("table").matches("CATEGORY")){
                                ca_create ca_create = new ca_create();
                                ca_create.insert(tmp);
                            }else if (_newObject.getString("table").matches("SUCURSAL")){
                                String _query = "INSERT INTO SUCURSAL VALUES(" +
                                        tmp.getInt("S_ID")+",'" +
                                        tmp.getString("S_Name")+"','" +
                                        tmp.getString("S_Address")+"')";
                                _database.insertData(_query);
                            }
                        }else if (_newObject.getString("action").matches("update")){
                            JSONObject tmp = _newObject.getJSONObject("model");
                            if (_newObject.getString("table").matches("CLIENT")){
                                cl_update cl_create = new cl_update();
                                cl_create.updateClient(tmp);
                            }else if (_newObject.getString("table").matches("WORKER")){
                                s_update s_update = new s_update();
                                s_update.updateSeller(tmp);
                            }else if (_newObject.getString("table").matches("PRODUCT")){
                                pr_update pr_update = new pr_update();
                                pr_update.updateProduct(tmp);
                            }else if (_newObject.getString("table").matches("PROVIDER")){
                                p_update p_update =  new p_update();
                                p_update.updateProvider(tmp);
                            }else if (_newObject.getString("table").matches("CATEGORY")){
                                ca_update ca_update = new ca_update();
                                ca_update.update(tmp);
                            }
                        }else if (_newObject.getString("action").matches("delete")){
                            JSONObject tmp = _newObject.getJSONObject("model");
                            if (_newObject.getString("table").matches("CLIENT")){
                                cl_delete cl_delete = new cl_delete();
                                cl_delete.deleteClient(tmp.getInt("C_ID"));
                            }else if (_newObject.getString("table").matches("PROVIDER")){
                                p_delete p_delete = new p_delete();
                                p_delete.deleteProvider(tmp.getInt("P_ID"));
                            }else if (_newObject.getString("table").matches("WORKER")){
                                String _query = "UPDATE WORKER SET W_Status='Deleted' WHERE W_ID="+tmp.getInt("W_ID");
                                _database.deleteData(_query);
                            }else if (_newObject.getString("table").matches("PRODUCT")){
                                pr_delete pr_delete = new pr_delete();
                                pr_delete.deleteProduct(tmp.getInt("PR_ID"));
                            }else if (_newObject.getString("table").matches("EORDER")){
                                or_delete or_delete=  new or_delete();
                                or_delete.deleteOrder(tmp.getInt("O_ID"));
                            }else if (_newObject.getString("table").matches("CATEGORY")){
                                ca_delete ca_delete = new ca_delete();
                                ca_delete.delete(tmp.getString("CA_ID"));
                            }
                        }
                    }
                }catch (JSONException e){
                    e.printStackTrace();
                }finally {
                    Toast.makeText(getBaseContext(),"There has been an error in the incoming data",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    public void Sync() throws UnsupportedEncodingException {
        final List<String> tmp = new ArrayList<>();
        for (int i = 0; i < _syncData.size(); i++){
            SyncHttpClient httpClient = new SyncHttpClient();
            if(_syncData.get(i).contains("post")){
                System.out.println("PRUEBA: "+_syncData.get(i));
                final String link = _syncData.get(i);
                String[] tmp1 = _syncData.get(i).split("@");
                String server = tmp1[0];
                StringEntity se = new StringEntity(tmp1[1]);
                System.out.println("PRUEBA: "+_syncData.get(i));
                System.out.println("PRUEBA: "+tmp1[1]);
                httpClient.post(getBaseContext(),server,se,"application/json",new JsonHttpResponseHandler(){
                    /**
                     * Returns when request failed
                     *
                     * @param statusCode    http response status line
                     * @param headers       response headers if any
                     * @param throwable     throwable describing the way request failed
                     * @param errorResponse parsed response if any
                     */
                    @Override
                    public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                        tmp.add(link);
                    }

                    /**
                     * Returns when request succeeds
                     *
                     * @param statusCode http response status line
                     * @param headers    response headers if any
                     * @param response   parsed response if any
                     */
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                        System.out.println("The action was completed");
                    }
                });
            } else if (_syncData.get(i).contains("update")){
                final String link = _syncData.get(i);
                String[] tmp1 = _syncData.get(i).split("/+");
                String server = tmp1[0];

                StringEntity se = new StringEntity(tmp1[1]);
                httpClient.put(getBaseContext(),server,se,"application/json",new JsonHttpResponseHandler(){
                    /**
                     * Returns when request failed
                     *
                     * @param statusCode    http response status line
                     * @param headers       response headers if any
                     * @param throwable     throwable describing the way request failed
                     * @param errorResponse parsed response if any
                     */
                    @Override
                    public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                        tmp.add(link);
                    }

                    /**
                     * Returns when request succeeds
                     *
                     * @param statusCode http response status line
                     * @param headers    response headers if any
                     * @param response   parsed response if any
                     */
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                        System.out.println("Action on success");
                    }
                });
            }else if (_syncData.get(i).contains("delete")){
                final String link = _syncData.get(i);
                System.out.println("ELIMINAR: "+_syncData.get(i));
                httpClient.get(getBaseContext(),_syncData.get(i),new JsonHttpResponseHandler(){
                    /**
                     * Returns when request succeeds
                     *
                     * @param statusCode http response status line
                     * @param headers    response headers if any
                     * @param response   parsed response if any
                     */
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                        tmp.add(link);
                    }

                    /**
                     * Returns when request failed
                     *
                     * @param statusCode    http response status line
                     * @param headers       response headers if any
                     * @param throwable     throwable describing the way request failed
                     * @param errorResponse parsed response if any
                     */
                    @Override
                    public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                        System.out.println("The action was completed");
                    }
                });
            }
        }
        _syncData = tmp;
    }
}
