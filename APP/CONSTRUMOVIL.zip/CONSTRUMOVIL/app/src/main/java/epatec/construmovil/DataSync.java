package epatec.construmovil;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Looper;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.SyncHttpClient;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.StringEntity;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/13/2016.
 */

public class DataSync extends AppCompatActivity{
    private static DataSync _instance = null;
    private ConnectivityManager _connectionManager;
    private List<String> _syncData = new ArrayList<>();
    private DBManager _database;
    private Integer _idSeller = 0;
    private Context _context;



    public List<String> get_syncData() {
        return _syncData;
    }

    private DataSync(ConnectivityManager pconnectionManager, Integer pIDSeller, Context context){
        _idSeller = pIDSeller;
        _connectionManager = pconnectionManager;
        _database = new DBManager(context);
        _context = context;
        startThread();
    }
    public static DataSync getInstance(ConnectivityManager pconnectionManager, Integer pIDSeller,Context context){
        if(_instance == null){
            _instance = new DataSync(pconnectionManager,pIDSeller,context);
        }
        return _instance;
    }
    public synchronized void startThread(){
        Thread _syncThread = new Thread(new Runnable() {
            @Override
            public void run() {
                NetworkInfo _info = _connectionManager.getActiveNetworkInfo();
                Looper.prepare();
                while(_info.isConnected()) {
                    try {

                            AskInfo();
                            Sync();

                    } catch (UnsupportedEncodingException e) {
                        e.printStackTrace();
                    }
                    try {
                        Thread.sleep(30000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        _syncThread.start();
    }
    public void AskInfo(){

        String server = "http://bryan:7580/api/sync/get/algo/"+_idSeller;
        SyncHttpClient httpClient = new SyncHttpClient();
        httpClient.get(getBaseContext(),server,new JsonHttpResponseHandler(){
            /**
             * Returns when request failed
             *
             * @param statusCode    http response status line
             * @param headers       response headers if any
             * @param throwable     throwable describing the way request failed
             * @param errorResponse parsed response if any
             */
            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONArray errorResponse) {
                Toast.makeText(_context,"There has been a sync error",Toast.LENGTH_LONG).show();
            }

            /**
             * Returns when request succeeds
             *
             * @param statusCode http response status line
             * @param headers    response headers if any
             * @param response   parsed response if any
             */
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONArray response) {

                    System.out.println("LA RESPUESTA HA SIDO DEL LADO DEL SERVER: "+response.toString());
                    for (int i = 0 ; i < response.length(); i++){
                        try {
                            JSONObject _newObject = response.getJSONObject(i);

                            if (_newObject.getString("action").matches("insert") | _newObject.getString("action").matches("INSERT")){
                                JSONObject tmp = new JSONObject(_newObject.getString("model"));
                                System.out.println("ESTE ES EL MODELO ACTUAL INSERT: "+tmp.toString());
                                if (_newObject.getString("table").matches("CLIENT")){
                                    String _queryClient = "INSERT INTO CLIENT VALUES(";
                                    String _query = _queryClient+tmp.getInt("C_ID")+",'"+tmp.getString("C_Name")
                                            + "','"+tmp.getString("C_LName")+"','"+tmp.getString("C_Address")+
                                            "',"+tmp.getInt("C_Phone")+",'"+tmp.getString("C_Date")+"',"
                                            +tmp.getInt("C_Penalization")+",'Available');";
                                    _database.insertData(_query);
                                }else if (_newObject.getString("table").matches("WORKER")){
                                        String _query = "INSERT INTO WORKER VALUES(" +
                                                tmp.getInt("W_ID") + ",'" +
                                                tmp.getString("W_Name") + "','" +
                                                tmp.getString("W_LName") + "','" +
                                                tmp.getString("W_Address") + "','" +
                                                tmp.getString("W_Password") + "','Available');";
                                        _database.insertData(_query);
                                }else if (_newObject.getString("table").matches("EORDER")){

                                    String _query = "INSERT INTO EORDER(O_ID,O_Priority,O_Status,O_PPhone,S_ID,C_ID,W_ID)" +
                                            " VALUES(" +
                                            tmp.getInt("O_ID")+"," +
                                            0+",'" +
                                            "Empacando'," +
                                            tmp.getInt("O_PPhone")+"," +
                                            tmp.getInt("S_ID")+"," +
                                            tmp.getInt("C_ID")+"," +
                                            tmp.getInt("W_ID")+");";
                                    String[] pid = tmp.getString("PR_ID").split(",");
                                    String[] pname = tmp.getString("PR_Name").split(",");
                                    String[] pamount = tmp.getString("PR_Amount").split(",");
                                    String[] pprice = tmp.getString("PR_Price").split(",");
                                    for (int j =0; j < pid.length;j++) {
                                        Random _number = new Random();
                                        int _order1 = _number.nextInt(9999 - 1) + 1;
                                         _query += "INSERT INTO ORDERXPRODUCT VALUES(" +
                                                _order1 + ","+
                                                tmp.getInt("O_ID") + "," +
                                                pid[j] + ",'" +
                                                pname[j] + "'," +
                                                pamount[j] + "," +
                                                pprice[j] + ");";
                                        System.out.println("EL QUERY TMP ES: "+_query);
                                    }
                                    _database.insertData(_query);
                                }else if (_newObject.getString("table").matches("PRODUCT")){
                                    String _query = "INSERT INTO PRODUCT VALUES(" + tmp.getInt("PR_ID") + ",'" +
                                            tmp.getString("PR_Name") + "',"+tmp.getString("PR_Price")+","+
                                            tmp.getInt("PR_Exempt")+",'"+tmp.getString("PR_Description")+"',"+tmp.getInt("PR_Quantity")+ ",'"+tmp.getString("PR_Status")+"'," +
                                            tmp.getInt("S_ID")+"," +
                                            tmp.getInt("P_ID")+");";
                                    String _query2 = "INSERT INTO CATEXPRODUCT(CA_ID,PR_ID,CXP_Status) VALUES('" +
                                            tmp.getString("CA_ID")+"'," +
                                            tmp.getInt("PR_ID")+",'Available');";
                                    System.out.println("LOS QUERYS SON: "+_query+" \n "+_query2);
                                    _database.insertData(_query);
                                    _database.insertData(_query2);
                                }else if (_newObject.getString("table").matches("PROVIDER")){
                                    String _insertProvider = "INSERT INTO PROVIDER VALUES(";
                                    String action = _insertProvider+tmp.getInt("P_ID")+",'"+
                                            tmp.getString("P_Name") + "','"+tmp.getString("P_LName")+"','"+
                                            tmp.getString("P_Address")+"','"+tmp.getString("P_Date")+"','Available');";
                                    _database.insertData(action);

                                }else if (_newObject.getString("table").matches("CATEGORY")){
                                    String _query = "INSERT INTO CATEGORY VALUES('" +
                                            tmp.getString("CA_ID") + "','" +
                                            tmp.getString("CA_Description") + "','Available');";
                                    _database.insertData(_query);
                                }else if (_newObject.getString("table").matches("SUCURSAL")){

                                        String _query = "INSERT INTO SUCURSAL VALUES(" +
                                                tmp.getInt("S_ID") + ",'" +
                                                tmp.getString("S_Name") + "','" +
                                                tmp.getString("S_Address") + "')";
                                        _database.insertData(_query);
                                    System.out.println("LA MIERDA QUE ESTÁ INSERTANDO: "+_query);

                                }
                            }else if (_newObject.getString("action").matches("update") | _newObject.getString("action").matches("UPDATE")){
                                JSONObject tmp = _newObject.getJSONObject("model");
                                System.out.println("ESTE ES EL MODELO ACTUAL update: "+tmp.toString());
                                if (_newObject.getString("table").matches("CLIENT")){
                                    String _query = "UPDATE CLIENT SET " +
                                            "C_Name='"+tmp.getString("C_Name")+"',"+
                                            "C_LName='"+tmp.getString("C_LName")+"',"+
                                            "C_Address='"+tmp.getString("C_Address")+"',"+
                                            "C_Date='"+tmp.getString("C_Date")+"',"+
                                            "C_Phone="+tmp.getInt("C_Phone")+
                                            " WHERE C_ID="+tmp.getInt("C_ID")+";";
                                    _database.updateData(_query);
                                }else if (_newObject.getString("table").matches("WORKER")){
                                    String _query = "UPDATE WORKER SET " +
                                            "W_Name='"+tmp.getString("W_Name")+"'," +
                                            "W_LName='"+tmp.getString("W_LName")+"'," +
                                            "W_Address='"+tmp.getString("W_Address")+"'," +
                                            "W_Status='"+tmp.getString("W_Status")+"' "+
                                            "WHERE W_ID="+tmp.getInt("W_ID")+";";
                                    _database.updateData(_query);
                                }else if (_newObject.getString("table").matches("PRODUCT")){
                                    String _query = "UPDATE PRODUCT SET "+
                                            "PR_Name='"+tmp.getString("PR_Name")+"',"+
                                            "PR_Price="+tmp.getString("PR_Price")+","+
                                            "PR_Exempt="+tmp.getInt("PR_Exempt")+"," +
                                            "PR_Description='"+tmp.getString("PR_Description")+"'," +
                                            "PR_Quantity="+tmp.getInt("PR_Quantity")+" WHERE PR_ID ="+
                                            tmp.getInt("PR_ID")+";";
                                    _database.updateData(_query);
                                }else if (_newObject.getString("table").matches("PROVIDER")){
                                    String _query = "UPDATE PROVIDER SET "+
                                            "P_Name ='"+tmp.getString("P_Name")+"',"+
                                            "P_LName='"+tmp.get("P_LName")+"',"+
                                            "P_Address='"+tmp.getString("P_Address")+"',"+
                                            "P_Date='"+tmp.getString("P_Date")+"' WHERE" +
                                            " P_ID="+tmp.getInt("P_ID")+";";
                                    _database.updateData(_query);
                                }else if (_newObject.getString("table").matches("CATEGORY")){
                                    String _query = "UPDATE CATEGORY SET CA_Description='"+tmp.get("CA_Description")+"' " +
                                            "WHERE CA_ID='"+tmp.getString("CA_ID")+"';";
                                    _database.updateData(_query);
                                }
                            }else if (_newObject.getString("action").matches("delete") | _newObject.getString("action").matches("DELETE")){
                                if (_newObject.getString("table").matches("CLIENT")){
                                    Integer tmp = _newObject.getInt("model");
                                    String _query = "UPDATE CLIENT SET C_Status='Deleted'WHERE C_ID="+tmp;
                                    _database.deleteData(_query);

                                }else if (_newObject.getString("table").matches("PROVIDER")){
                                    Integer tmp = _newObject.getInt("model");
                                    String _query = "UPDATE PROVIDER SET P_Status='Deleted' WHERE P_ID="+tmp;
                                    _database.deleteData(_query);


                                }else if (_newObject.getString("table").matches("WORKER")){
                                    Integer tmp = _newObject.getInt("model");
                                    String _query = "UPDATE WORKER SET W_Status='Deleted' WHERE W_ID="+tmp;
                                    _database.deleteData(_query);

                                }else if (_newObject.getString("table").matches("PRODUCT")){
                                    Integer tmp = _newObject.getInt("model");
                                    String _deleteProduct = "UPDATE PRODUCT SET PR_Status='Deleted' WHERE PR_ID="+tmp;
                                    String _deleteProduct1 = "UPDATE CATEXPRODUCT SET CXP_Status='Deleted' WHERE PR_ID="+tmp;
                                    _database.deleteData(_deleteProduct);
                                    _database.deleteData(_deleteProduct1);

                                }else if (_newObject.getString("table").matches("EORDER")){
                                    Integer tmp = _newObject.getInt("model");
                                    String _query1 = "DELETE FROM ORDERXPRODUCT WHERE O_ID="+tmp;
                                    String _query2 = "DELETE FROM EORDER WHERE O_ID="+tmp;
                                    _database.deleteData(_query1);
                                    _database.deleteData(_query2);

                                }else if (_newObject.getString("table").matches("CATEGORY")){
                                    String tmp = _newObject.getString("model");
                                    String _query1 = "SELECT PR_ID FROM CATEXPRODUCT WHERE CA_ID='"+tmp+"';";
                                    Cursor _cursor = _database.selectData(_query1);
                                    if (_cursor.moveToFirst()){
                                        do{
                                            String _query2 = "UPDATE PRODUCT SET PR_Status='Deleted' WHERE PR_ID="+_cursor.getInt(0);
                                            _database.deleteData(_query2);
                                        }while (_cursor.moveToNext());
                                    }
                                    String _query3 = "UPDATE CATEXPRODUCT SET CXP_Status='Deleted' WHERE CA_ID='"+tmp+"';";
                                    String _query4 = "UPDATE CATEGORY SET CA_Status='Deleted' WHERE CA_ID='"+tmp+"';";
                                    try {
                                        _database.deleteData(_query3);
                                        _database.deleteData(_query4);
                                    }catch (SQLiteException e){
                                        System.out.println("HA HABIDO UN ERROR");
                                    }
                                }
                            }
                            System.out.println("LA INSERCIÓN SE HA HECHO");
                            Thread.sleep(600);
                        }catch (JSONException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            System.out.println("TUVO QUE CORTAR EL TIEMPO DE ESPERA");
                        } finally {
                            continue;
                        }
                    }
            }
        });
    }
    public void Sync() throws UnsupportedEncodingException {
        final List<String> tmp = new ArrayList<>();
        for (int i = 0; i < _syncData.size(); i++){
            SyncHttpClient httpClient = new SyncHttpClient();
            if(_syncData.get(i).contains("post")){
                System.out.println("PRUEBA: "+_syncData.get(i));
                final String link = _syncData.get(i);
                String[] tmp1 = _syncData.get(i).split("@");
                String server = tmp1[0];
                StringEntity se = new StringEntity(tmp1[1]);
                System.out.println("PRUEBA: "+_syncData.get(i));
                System.out.println("PRUEBA: "+tmp1[1]);
                httpClient.post(getBaseContext(),server,se,"application/json",new JsonHttpResponseHandler(){
                    /**
                     * Returns when request failed
                     *
                     * @param statusCode    http response status line
                     * @param headers       response headers if any
                     * @param throwable     throwable describing the way request failed
                     * @param errorResponse parsed response if any
                     */
                    @Override
                    public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                        tmp.add(link);
                    }

                    /**
                     * Returns when request succeeds
                     *
                     * @param statusCode http response status line
                     * @param headers    response headers if any
                     * @param response   parsed response if any
                     */
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                        System.out.println("The action was completed");
                    }
                });
            } else if (_syncData.get(i).contains("update")){
                final String link = _syncData.get(i);
                String[] tmp1 = _syncData.get(i).split("@");
                String server = tmp1[0];

                StringEntity se = new StringEntity(tmp1[1]);
                System.out.println("EL UPDATE LO ESTÁ HACIENDO CON: "+link);
                httpClient.put(getBaseContext(),server,se,"application/json",new JsonHttpResponseHandler(){
                    @Override
                    public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                        System.out.println("HUBO UN ERROR EN EL UPDATE");
                        tmp.add(link);
                    }

                    /**
                     * Returns when request failed
                     *
                     * @param statusCode    http response status line
                     * @param headers       response headers if any
                     * @param throwable     throwable describing the way request failed
                     * @param errorResponse parsed response if any
                     */
                    @Override
                    public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                        tmp.add(link);
                    }

                    /**
                     * Returns when request succeeds
                     *
                     * @param statusCode http response status line
                     * @param headers    response headers if any
                     * @param response   parsed response if any
                     */
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                        System.out.println("Action on success");
                    }
                });
            }else if (_syncData.get(i).contains("delete")){
                final String link = _syncData.get(i);
                System.out.println("ELIMINAR: "+_syncData.get(i));
                httpClient.get(getBaseContext(),_syncData.get(i),new JsonHttpResponseHandler(){
                    /**
                     * Returns when request succeeds
                     *
                     * @param statusCode http response status line
                     * @param headers    response headers if any
                     * @param response   parsed response if any
                     */
                    @Override
                    public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                        //tmp.add(link);
                    }

                    /**
                     * Returns when request failed
                     *
                     * @param statusCode    http response status line
                     * @param headers       response headers if any
                     * @param throwable     throwable describing the way request failed
                     * @param errorResponse parsed response if any
                     */
                    @Override
                    public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                        System.out.println("The action was completed");
                    }
                });
            }
        }
        _syncData = tmp;
    }
}
