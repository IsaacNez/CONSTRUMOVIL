package epatec.construmovil;

import android.app.Activity;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/13/2016.
 */

public class DataSync extends Activity{
    private static DataSync _instance = null;
    private ConnectivityManager _connectionManager;
    private List<String> _syncData = new ArrayList<>();
    private Integer _idSeller = 0;

    public List<String> get_syncData() {
        return _syncData;
    }

    private DataSync(ConnectivityManager pconnectionManager, Integer pIDSeller){
        _idSeller = pIDSeller;
        _connectionManager = pconnectionManager;
        startThread();
    }
    public static DataSync getInstance(ConnectivityManager pconnectionManager, Integer pIDSeller){
        if(_instance == null){
            _instance = new DataSync(pconnectionManager,pIDSeller);
        }
        return _instance;
    }
    public synchronized void startThread(){
        Thread _syncThread = new Thread(new Runnable() {
            @Override
            public void run() {
                NetworkInfo _info = _connectionManager.getActiveNetworkInfo();
                while(_info.isAvailable()) {
                    Sync();
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        _syncThread.start();
    }
    private void Sync(){
        for (int i = 0; i < _syncData.size(); i++){
            if(_syncData.get(i).contains("post")){
                System.out.println("SE ESTÁ HACIENDO UN POST");
            } else if (_syncData.get(i).contains("update")){
                System.out.println("SE ESTÁ HACIENDO UN UPDATE");
            }else if (_syncData.get(i).contains("delete")){
                System.out.println("SE ESTÁ HACIENDO UN DELETE");
            }
        }
    }
}
