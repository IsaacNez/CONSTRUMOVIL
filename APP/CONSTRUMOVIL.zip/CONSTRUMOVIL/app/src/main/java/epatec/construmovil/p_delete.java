package epatec.construmovil;

import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.ConnectivityManager;
import android.support.annotation.StringDef;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/13/2016.
 */

public class p_delete extends Fragment {
    View _myView;
    EditText _providerDelete;
    Button _searchProvider;
    ListView _providersList;

    DBManager _database;
    private List<String> _providersNames;
    private List<JSONObject> _providers;
    ArrayAdapter<String> _listView;

    Integer _ID;

    ConnectivityManager _connectionManager;

    String _toSend = "";

    Integer _wID = 0;


    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.p_delete,null);
        _database = new DBManager(getContext());
        _connectionManager = (ConnectivityManager) getContext().getSystemService(CONNECTIVITY_SERVICE);
        _wID = getArguments().getInt("W_ID",0);
        _toSend = getString(R.string.server_url)+"api/provider/delete/";

        _providerDelete = (EditText) _myView.findViewById(R.id._providerDelete);
        _searchProvider = (Button) _myView.findViewById(R.id._searchProvider);
        _providersList = (ListView) _myView.findViewById(R.id._providersList);

        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                _searchProvider.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        System.out.println("PORQUE ESTA MIERDA NO FUNCIONA");
                        if (_providerDelete.getText().toString().matches(""))
                            Snackbar.make(v, "You must provide a search parameter",Snackbar.LENGTH_LONG).show();
                        else{
                            String query = "SELECT * FROM PROVIDER WHERE P_Name LIKE '%" + _providerDelete.getText().toString() + "%' AND P_Status <> 'Deleted';";
                            final Cursor _cursor = _database.selectData(query);
                            System.out.println("LA CANTIDAD DE PROVEEDORES QUE HAY SON: "+_cursor.getCount());
                            loadData(_cursor);


                        }
                    }
                });

                _providersList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        JSONObject _js = _providers.get(position);
                        try {
                            _ID = _js.getInt("P_ID");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        AlertDialog.Builder _alert = new AlertDialog.Builder(getContext());
                        _alert.setIcon(R.drawable.ic_delete_black_24dp);
                        _alert.setTitle("Delete this provider?");
                        _alert.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                deleteProvider(_ID);
                                String _temp = _toSend+"P_ID,ID_Seller/"+_ID+","+_wID;
                                DataSync.getInstance(_connectionManager,_wID,getContext()).get_syncData().add(_temp);
                                List<String> _tmp = new ArrayList<String>();
                            }
                        })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                });
                        _alert.show();
                    }
                });
            }
        });


        return _myView;
    }
    public void deleteProvider(Integer _pID){

        String _query = "UPDATE PROVIDER SET P_Status='Deleted' WHERE P_ID="+_pID;
        try {
            _database.deleteData(_query);
        }catch (SQLiteException e){
            Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
    private void loadData(final Cursor _cursor){
        _providersNames = new ArrayList<String>();
        _providers = new ArrayList<JSONObject>();
        if(_cursor.moveToFirst()){
            do {
                try {
                    JSONObject params = new JSONObject();
                    params.put("P_ID", _cursor.getInt(0));
                    params.put("P_Name", _cursor.getString(1));
                    params.put("P_LName", _cursor.getString(2));
                    params.put("P_Address", _cursor.getString(3));
                    params.put("P_Date", _cursor.getString(4));
                    _providers.add(params);
                    _providersNames.add(_cursor.getString(1) + " " + _cursor.getString(2));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }while(_cursor.moveToNext());
        }
        _listView = new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,_providersNames);
        _providersList.setAdapter(_listView);
        _listView.notifyDataSetChanged();
    }
}
