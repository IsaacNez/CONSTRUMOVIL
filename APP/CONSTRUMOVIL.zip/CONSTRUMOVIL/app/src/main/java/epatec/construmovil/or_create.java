package epatec.construmovil;

import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.ConnectivityManager;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/6/2016.
 */

public class or_create extends Fragment {
    View _myView;

    Spinner _pickupLocation, _clientOption;
    EditText _favoritePhone;
    ListView _productsOrder;
    Button _orderButton;

    Integer _sID,_cID,_wID = 0;

    ArrayAdapter<String> _subsidiaryAdapter,_clientAdapter,_productAdapter;

    DBManager _database;
    ConnectivityManager _connectionManager;

    List<String> _subsidiaryName,_productName,_names,_listName,_listAmount;
    List<Integer> _subsidiaryID,_clientID,_listPrice, _productID;
    List<JSONObject> _productList;

    String _toSync = "";

    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.or_create,null);
        _wID = getArguments().getInt("W_ID",0);
        _pickupLocation = (Spinner) _myView.findViewById(R.id._pickuplocation);
        _clientOption = (Spinner) _myView.findViewById(R.id._clientOption);
        _favoritePhone = (EditText) _myView.findViewById(R.id._favoritePhone);
        _productsOrder = (ListView) _myView.findViewById(R.id._productsOrder);
        _orderButton = (Button) _myView.findViewById(R.id._orderButton);
        _database = new DBManager(getContext());
        _listName = new ArrayList<>();
        _listAmount = new ArrayList<>();
        _listPrice = new ArrayList<>();
        _productID = new ArrayList<>();
        _toSync = getString(R.string.server_url)+"api/order/post@";
        _connectionManager = (ConnectivityManager)getContext().getSystemService(CONNECTIVITY_SERVICE);
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                loadSubsidiary();
                loadProducts();
                loadClients();
                _orderButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (_subsidiaryName.size() == 0 | _clientID.size() == 0 | _productName.size() == 0 | _favoritePhone.getText().toString().matches("")) {
                            Snackbar.make(v, "You can´t order any product at this moment. Please try it later", Snackbar.LENGTH_LONG).show();
                        }if(_listName.size()==0){
                            Snackbar.make(v,"You must add some products to your order",Snackbar.LENGTH_LONG).show();
                        }else {
                            Random _number = new Random();
                            int _order = _number.nextInt(9999 - 1) + 1;
                            String _name = "";
                            String _ID = "";
                            String _amount = "";
                            String _price = "";

                            for(int i = 0; i < _listName.size();i++){
                                if(i == _listName.size()-1){
                                    _ID += _productID.get(i);
                                    _name += _listName.get(i);
                                    _amount += _listAmount.get(i);
                                    _price += _listPrice.get(i);
                                }else{
                                    _ID += _productID.get(i)+",";
                                    _name += _listName.get(i)+",";
                                    _amount += _listAmount.get(i)+",";
                                    _price += _listPrice.get(i)+",";
                                }

                            }
                            Date cDate = new Date();
                            String fDate = new SimpleDateFormat("yyyy-MM-dd").format(cDate);
                            try{
                                JSONObject params = new JSONObject();

                                params.put("O_ID",_order);
                                params.put("O_Priority",0);
                                params.put("O_Status","Empacando");
                                params.put("O_Date",fDate);
                                params.put("O_PPhone",_favoritePhone.getText().toString());
                                params.put("PR_ID",_ID);
                                params.put("PR_Name",_name);
                                params.put("PR_Amount",_amount);
                                params.put("PR_Price",_price);
                                params.put("S_ID",_sID);
                                params.put("C_ID",_cID);
                                params.put("W_ID",_wID);
                                params.put("ID_Seller",_wID);
                                insertOrder(params);
                                String _queue = _toSync+params.toString();
                                DataSync.getInstance(_connectionManager,_wID,getContext()).get_syncData().add(_queue);
                            }catch (JSONException e){
                                e.printStackTrace();
                            }
                            _listName = new ArrayList<>();
                            _listAmount = new ArrayList<>();
                            _listPrice = new ArrayList<>();
                            _productID = new ArrayList<>();
                            Snackbar.make(v, "The order was created successfully",Snackbar.LENGTH_LONG).show();
                        }
                    }
                });

                _pickupLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        _sID = _subsidiaryID.get(position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                _clientOption.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        _cID = _clientID.get(position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                _productsOrder.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, final View view, final int position, long id) {
                        final AlertDialog.Builder _auxWindow = new AlertDialog.Builder(getContext());
                        final EditText _quantity = new EditText(getContext());
                        _auxWindow.setView(_quantity);
                        _auxWindow.setTitle("Add this product?");
                        _auxWindow.setPositiveButton("Add", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                if (_quantity.getText().toString().matches("")) {
                                    Snackbar.make(view, "You must provide a quantity", Snackbar.LENGTH_LONG).show();

                                }else{
                                    try{
                                        JSONObject object = _productList.get(position);
                                        _productID.add(object.getInt("PR_ID"));
                                        _listName.add(object.getString("PR_Name"));
                                        _listPrice.add(object.getInt("PR_Price"));
                                        _listAmount.add(_quantity.getText().toString());
                                        System.out.println("LA ORDEN CONSTA DE: "+object.getInt("PR_ID")+" "+object.getString("PR_Name")+" "+_quantity.getText().toString());
                                        dialog.cancel();
                                    }catch (JSONException e){
                                        e.printStackTrace();
                                    }
                                }
                            }
                        })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {

                                    }
                                });
                        _auxWindow.show();
                    }
                });
            }
        });
        return _myView;
    }

    /**
     * Inserta una orden donde toma en consideración los datos
     * que el usuario provee como lso productos y el teléfono
     * favorito
     * @param params
     */
    public void insertOrder(JSONObject params){

        try{
            Random _number = new Random();
            int _order1 = _number.nextInt(9999 - 1) + 1;
            String _query = "INSERT INTO EORDER(O_ID,O_Priority,O_Status,O_PPhone,S_ID,C_ID,W_ID)" +
                    " VALUES(" +
                    params.getInt("O_ID")+"," +
                    0+",'" +
                    "Empacando'," +
                    params.getInt("O_PPhone")+"," +
                    params.getInt("S_ID")+"," +
                    params.getInt("C_ID")+"," +
                    params.getInt("W_ID")+");";
            _database.insertData(_query);
            System.out.println("LA ORDEN ES: "+params.toString());
            if (params.getString("PR_ID").contains(",")) {
                String[] pid = params.getString("PR_ID").split(",");
                String[] pname = params.getString("PR_Name").split(",");
                String[] pamount = params.getString("PR_Amount").split(",");
                String[] pprice = params.getString("PR_Price").split(",");

                for (int i = 0; i < pid.length; i++) {
                    String _tmp = "INSERT INTO ORDERXPRODUCT(O_ID,PR_ID,PR_Name,PR_Amount,PR_Price) VALUES(" +
                            _order1 + ","+
                            params.getInt("O_ID") + "," +
                            pid[i] + ",'" +
                            pname[i] + "'," +
                            pamount[i] + "," +
                            pprice[i] + ");";
                    _database.insertData(_tmp);
                    System.out.println("LA SEGUNDA ORDEN ES: " + _tmp);
                }
            }else{
                String _tmp = "INSERT INTO ORDERXPRODUCT VALUES(" +
                        _order1 + ","+
                        params.getInt("O_ID") + "," +
                        params.getString("PR_ID") + ",'" +
                        params.getString("PR_Name")+ "'," +
                        params.getString("PR_Amount") + "," +
                        params.getString("PR_Price")+ ");";
                _database.insertData(_tmp);
                System.out.println("LA TERCERA ORDEN ES: " + _tmp);
            }
        }catch (JSONException e){
            e.printStackTrace();
        }catch (SQLiteException e){
            Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Cargas las sucuarsales que no han sido
     * eliminados.
     */
    private void loadSubsidiary(){
        _subsidiaryName = new ArrayList<>();
        _subsidiaryID = new ArrayList<>();
        String _query = "SELECT * FROM SUCURSAL;";
        Cursor _cursor = _database.selectData(_query);
        if (_cursor.moveToFirst()){
            do{
                _subsidiaryName.add(_cursor.getString(1));
                _subsidiaryID.add(_cursor.getInt(0));
            }while (_cursor.moveToNext());
        }
        _subsidiaryAdapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_subsidiaryName);
        _pickupLocation.setAdapter(_subsidiaryAdapter);
        _subsidiaryAdapter.notifyDataSetChanged();
    }

    /**
     * Carga los productos que no han sido eliminados
     */

    private void loadProducts(){
        _productName = new ArrayList<>();
        _productList = new ArrayList<>();

        String _query = "SELECT * FROM PRODUCT WHERE PR_Status <> 'Deleted'";
        Cursor _cursor = _database.selectData(_query);
        System.out.println("LA CUENTA DE LOS PRODUCTOS HA SIDO: "+_cursor.getCount());
        if (_cursor.moveToFirst()){
            do{
                Integer _prid = _cursor.getInt(0);
                String _prname = _cursor.getString(1);
                Integer _prprice = _cursor.getInt(2);
                Integer _prexempt = _cursor.getInt(3);
                String _prdescrip = _cursor.getString(4);
                Integer _prquantity = _cursor.getInt(5);
                try {
                    JSONObject params = new JSONObject();
                    params.put("PR_ID", _prid);
                    params.put("PR_Name", _prname);
                    params.put("PR_Price", _prprice);
                    params.put("PR_Exempt", _prexempt);
                    params.put("PR_Description", _prdescrip);
                    params.put("PR_Quantity", _prquantity);
                    _productName.add(_prname);
                    _productList.add(params);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }while (_cursor.moveToNext());
        }
        _productAdapter = new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,_productName);
        _productsOrder.setAdapter(_productAdapter);
        _productAdapter.notifyDataSetChanged();
    }

    /**
     * Carga los clientes que no han sido
     * eliminados
     */
    private void loadClients(){
        String _query = "SELECT * FROM CLIENT WHERE C_Status <> 'Deleted';";
        Cursor _cursor = _database.selectData(_query);
        _names = new ArrayList<>();
        _clientID = new ArrayList<>();
        if (_cursor.moveToFirst()){
            do{
                _clientID.add(_cursor.getInt(0));
                _names.add(_cursor.getString(1)+" "+_cursor.getString(2));
            }while (_cursor.moveToNext());
        }
        _clientAdapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_names);
        _clientOption.setAdapter(_clientAdapter);
        _clientAdapter.notifyDataSetChanged();
    }
}
