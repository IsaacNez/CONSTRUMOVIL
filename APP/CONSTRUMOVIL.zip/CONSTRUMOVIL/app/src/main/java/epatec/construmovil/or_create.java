package epatec.construmovil;

import android.content.DialogInterface;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/6/2016.
 */

public class or_create extends Fragment {
    View _myView;

    Spinner _pickupLocation, _clientOption;
    EditText _favoritePhone;
    ListView _productsOrder;
    Button _orderButton;

    Integer _sID,_cID,_wID = 0;

    ArrayAdapter<String> _subsidiaryAdapter,_clientAdapter,_productAdapter;

    DBManager _database;
    ConnectivityManager _connectionManager;

    List<String> _subsidiaryName,_productName,_names,_listName,_listAmount;
    List<Integer> _subsidiaryID,_clientID,_listPrice;
    List<JSONObject> _productList;

    String _toSync = "";

    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.or_create,null);
        _pickupLocation = (Spinner) _myView.findViewById(R.id._pickuplocation);
        _clientOption = (Spinner) _myView.findViewById(R.id._clientOption);
        _favoritePhone = (EditText) _myView.findViewById(R.id._favoritePhone);
        _productsOrder = (ListView) _myView.findViewById(R.id._productsOrder);
        _orderButton = (Button) _myView.findViewById(R.id._orderButton);
        _database = new DBManager(getContext());
        _listName = new ArrayList<>();
        _listAmount = new ArrayList<>();
        _listPrice = new ArrayList<>();
        _toSync = getString(R.string.server_url)+"api/order/post+";
        _connectionManager = (ConnectivityManager)getContext().getSystemService(CONNECTIVITY_SERVICE);
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                loadSubsidiary();
                loadProducts();
                loadClients();
                _orderButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (_subsidiaryName.size() == 0 | _clientID.size() == 0 | _productName.size() == 0 | _favoritePhone.getText().toString().matches("")) {
                            Snackbar.make(v, "You can´t order any product at this moment. Please try it later", Snackbar.LENGTH_LONG).show();
                        }if(_listName.size()==0){
                            Snackbar.make(v,"You must add some products to your order",Snackbar.LENGTH_LONG).show();
                        }else {
                            Random _number = new Random();
                            int _order = _number.nextInt(99999999 - 1) + 1;
                            String _name = "";
                            String _amount = "";
                            String _price = "";
                            String _query = "INSERT INTO ORDER(O_ID,O_Priority,O_Status,O_PPhone,S_ID,C_ID,W_ID)" +
                                    " VALUES(" +
                                    _order+"," +
                                    0+",'" +
                                    "Empacando'," +
                                    _favoritePhone.getText().toString()+"," +
                                    _sID+"," +
                                    _cID+"," +
                                    _wID+");";
                            _database.insertData(_query);
                            for(int i = 0; i < _listName.size();i++){
                                if(i == _listName.size()-1){
                                    _name += _listName.get(i);
                                    _amount += _listAmount.get(i);
                                    _price += _listPrice.get(i);
                                }else{
                                    _name += _listName.get(i)+",";
                                    _amount += _listAmount.get(i)+",";
                                    _price += _listPrice.get(i)+",";
                                }
                                String _tmp = "INSERT INTO ORDERXPRODUCT VALUES(" +
                                        _order+",'" +
                                        _listName.get(i)+"'," +
                                        _listAmount.get(i)+"," +
                                        _listPrice.get(i)+");";
                                _database.insertData(_tmp);
                                }
                            Date cDate = new Date();
                            String fDate = new SimpleDateFormat("yyyy-MM-dd").format(cDate);
                            try{
                                JSONObject params = new JSONObject();
                                params.put("O_ID",_order);
                                params.put("O_Priority",0);
                                params.put("O_Status","Empacando");
                                params.put("O_Date",fDate);
                                params.put("O_PPhone",_favoritePhone.getText().toString());
                                params.put("S_ID",_sID);
                                params.put("C_ID",_cID);
                                params.put("W_ID",_wID);
                                String _queue = _toSync+params.toString();
                                DataSync.getInstance(_connectionManager,_wID).get_syncData().add(_queue);
                            }catch (JSONException e){
                                e.printStackTrace();
                            }
                        }
                    }
                });

                _pickupLocation.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        _sID = _subsidiaryID.get(position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                _clientOption.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        _cID = _clientID.get(position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                _productsOrder.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, final View view, final int position, long id) {
                        final AlertDialog.Builder _auxWindow = new AlertDialog.Builder(getContext());
                        final EditText _quantity = new EditText(getContext());
                        _auxWindow.setView(_quantity);
                        _auxWindow.setTitle("Add this product?");
                        _auxWindow.setPositiveButton("Add",null)
                                .setNegativeButton("Cancel",null);
                        final AlertDialog _aux = _auxWindow.create();
                        _aux.setOnShowListener(new DialogInterface.OnShowListener() {
                            @Override
                            public void onShow(final DialogInterface dialog) {
                                Button add = _aux.getButton(AlertDialog.BUTTON_POSITIVE);
                                add.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        if (_quantity.getText().toString().matches("")) {
                                            Snackbar.make(view, "You must provide a quantity", Snackbar.LENGTH_LONG).show();

                                        }else{
                                            try{
                                                JSONObject object = _productList.get(position);
                                                _listName.add(object.getString("PR_Name"));
                                                _listPrice.add(object.getInt("PR_Price"));
                                                _listAmount.add(_quantity.getText().toString());
                                                dialog.cancel();
                                            }catch (JSONException e){
                                                e.printStackTrace();
                                            }
                                        }
                                    }
                                });

                                Button cancel = _aux.getButton(AlertDialog.BUTTON_NEGATIVE);
                                cancel.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        dialog.cancel();
                                    }
                                });
                            }
                        });
                        _auxWindow.show();
                    }
                });
            }
        });
        return _myView;
    }

    private void loadSubsidiary(){
        _subsidiaryName = new ArrayList<>();
        _subsidiaryID = new ArrayList<>();
        String _query = "SELECT * FROM SUCURSAL;";
        Cursor _cursor = _database.selectData(_query);
        if (_cursor.moveToFirst()){
            do{
                _subsidiaryName.add(_cursor.getString(1));
                _subsidiaryID.add(_cursor.getInt(0));
            }while (_cursor.moveToNext());
        }
        _subsidiaryAdapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_subsidiaryName);
        _pickupLocation.setAdapter(_subsidiaryAdapter);
        _subsidiaryAdapter.notifyDataSetChanged();
    }

    private void loadProducts(){
        _productName = new ArrayList<>();
        _productList = new ArrayList<>();
        String _query = "SELECT * FROM PRODUCT";
        Cursor _cursor = _database.selectData(_query);
        if (_cursor.moveToFirst()){
            do{
                Integer _prid =_cursor.getInt(0);
                String _prname =_cursor.getString(1);
                Integer _prprice =_cursor.getInt(2);
                Integer _prexempt =_cursor.getInt(3);
                String _prdescrip =_cursor.getString(4);
                Integer _prquantity =_cursor.getInt(5);
                try{
                    JSONObject params = new JSONObject();
                    params.put("PR_ID",_prid);
                    params.put("PR_Name",_prname);
                    params.put("PR_Price",_prprice);
                    params.put("PR_Exempt",_prexempt);
                    params.put("PR_Description",_prdescrip);
                    params.put("PR_Quantity",_prquantity);
                    _productName.add(_prname);
                    _productList.add(params);
                }catch (JSONException e){
                    e.printStackTrace();
                }

            }while (_cursor.moveToNext());
        }
        _productAdapter = new ArrayAdapter<String>(getContext(),android.R.layout.simple_list_item_1,_productName);
        _productsOrder.setAdapter(_productAdapter);
        _productAdapter.notifyDataSetChanged();
    }

    private void loadClients(){
        String _query = "SELECT * FROM CLIENT;";
        Cursor _cursor = _database.selectData(_query);
        _names = new ArrayList<>();
        _clientID = new ArrayList<>();
        if (_cursor.moveToFirst()){
            do{
                _clientID.add(_cursor.getInt(0));
                _names.add(_cursor.getString(1)+" "+_cursor.getString(2));
            }while (_cursor.moveToNext());
        }
        _clientAdapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_names);
        _clientOption.setAdapter(_clientAdapter);
        _clientAdapter.notifyDataSetChanged();
    }
}
