package epatec.construmovil;

import android.net.ConnectivityManager;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/13/2016.
 */

public class p_create extends Fragment {
    View _myView;

    EditText _pid;
    EditText _pname;
    EditText _plname;
    EditText _paddress;
    EditText _pbdate;

    Button _providerRegister;

    String _insertProvider = "INSERT INTO PROVIDER VALUES(";
    String _toSync = "";
    DBManager _database;
    ConnectivityManager _connectionManager;
    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.p_create,null);

        _toSync = getString(R.string.server_url)+"api/provider/post+";

        _pid = (EditText) _myView.findViewById(R.id.p_id);
        _pname = (EditText) _myView.findViewById(R.id.p_name);
        _plname = (EditText) _myView.findViewById(R.id.p_lname);
        _paddress = (EditText) _myView.findViewById(R.id.p_address);
        _pbdate = (EditText) _myView.findViewById(R.id.p_bdate);

        _database = new DBManager(getContext());
        _connectionManager = (ConnectivityManager)getContext().getSystemService(CONNECTIVITY_SERVICE);

        _providerRegister = (Button) _myView.findViewById(R.id._providerRegister);

        _providerRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String _providerID = _pid.getText().toString();
                String _providerName = _pname.getText().toString();
                String _providerLName = _plname.getText().toString();
                String _providerAddress = _paddress.getText().toString();
                String _providerBDate = _pbdate.getText().toString();
                if (!_providerID.matches("") | !_providerName.matches("") | !_providerLName.matches("") | !_providerAddress.matches("") |  !_providerBDate.matches("")){
                    Snackbar.make(v, "You must fill all the data",Snackbar.LENGTH_LONG).show();
                }
                if (!_providerBDate.matches("^\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])$")){
                    _pbdate.setError("You must enter a valid birth date. Thanks");
                }else{
                    try{
                        JSONObject params = new JSONObject();
                        params.put("P_ID", _providerID);
                        params.put("P_Name", _providerName);
                        params.put("P_LName",_providerLName);
                        params.put("P_Address",_providerAddress);
                        params.put("P_Date",_providerBDate);
                        String action = _insertProvider+_providerID+",'"+
                                _providerName + "','"+_providerLName+"','"+
                                _providerAddress+"','"+_providerBDate+"');";
                        _database.insertData(action);
                        Snackbar.make(v, "The provider was succesfully created",Snackbar.LENGTH_LONG).show();
                        String _tmp = _toSync+params.toString();
                        DataSync.getInstance(_connectionManager,1234).get_syncData().add(_tmp);
                    }catch (JSONException e){
                        e.printStackTrace();
                    }
                }
            }
        });
        return _myView;
    }
}
