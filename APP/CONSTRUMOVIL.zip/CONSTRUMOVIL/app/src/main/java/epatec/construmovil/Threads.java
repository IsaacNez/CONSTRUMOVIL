package epatec.construmovil;

/**
 * Created by Isaac on 11/7/2016.
 */

public class Threads {

    private static Threads _instance = null;

    private Threads(){

    }

    public static Threads getInstance(){
        if (_instance == null){
            _instance = new Threads();
        }
        return _instance;
    }
}
