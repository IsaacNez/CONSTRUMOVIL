package epatec.construmovil;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Isaac on 11/6/2016.
 */

public class pr_create extends Fragment {
    View _myView;
    Spinner _subsidiarySpinner,_productProvider;
    EditText _productName,_productDescription,_productQuantity;
    CheckBox _yesExempt;
    Button _productRegister;

    List<Integer> _subsidiaryID = new ArrayList<>();
    List<String> _subsidiaryView = new ArrayList<>();
    List<Integer> _providerID = new ArrayList<>();
    List<String> _providerShow = new ArrayList<>();

    Integer _subsidiaryPosition = 0;
    Integer _providerPosition = 0;

    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.pr_create,null);
        loadProvider();
        loadSubsidiary();
        _subsidiarySpinner = (Spinner) _myView.findViewById(R.id._subsidiarySpinner);
        _productProvider = (Spinner) _myView.findViewById(R.id._productProvider);
        _productName = (EditText) _myView.findViewById(R.id._productName);
        _productDescription = (EditText) _myView.findViewById(R.id._productDescription);
        _productQuantity = (EditText) _myView.findViewById(R.id._productQuantity);
        _yesExempt = (CheckBox) _myView.findViewById(R.id._yesExempt);
        _productRegister = (Button) _myView.findViewById(R.id._productRegister);

        ArrayAdapter<String> _subsidiaryAdapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_subsidiaryView);
        _subsidiarySpinner.setAdapter(_subsidiaryAdapter);

        ArrayAdapter<String> _providerAdapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_providerShow);
        _productProvider.setAdapter(_providerAdapter);

        _subsidiarySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                _subsidiaryPosition = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        _productProvider.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                _providerPosition = position;
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        return _myView;
    }
    private void loadSubsidiary(){
        //Here must do some shit
    }
    private void loadProvider(){
        //Here must do some shit
    }
}
