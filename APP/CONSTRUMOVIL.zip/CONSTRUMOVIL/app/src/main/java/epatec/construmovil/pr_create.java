package epatec.construmovil;

import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.ConnectivityManager;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/6/2016.
 */

public class pr_create extends Fragment {
    View _myView;
    Spinner _subsidiarySpinner,_productProvider,_productCategory;
    EditText _productName,_productDescription,_productQuantity;
    CheckBox _yesExempt;
    Button _productRegister;
    EditText _productPrice;

    List<Integer> _subsidiaryID;
    List<String> _subsidiaryView;
    List<Integer> _providerID = new ArrayList<>();
    List<String> _providerShow,_productCategoryList;

    Integer _subsidiaryPosition = 0;
    Integer _providerPosition,_wID = 0;

    DBManager _database;
    private List<JSONObject> _providers;

    ArrayAdapter<String> _providerAdapter;
    ArrayAdapter<String> _subsidiaryAdapter,_categoryAdapter;

    String _toSync = "";
    String _category = "";

    ConnectivityManager _connectionManager;

    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.pr_create,null);
        _database = new DBManager(getContext());
        _connectionManager = (ConnectivityManager)getContext().getSystemService(CONNECTIVITY_SERVICE);
        _wID = getArguments().getInt("W_ID",0);
        _subsidiarySpinner = (Spinner) _myView.findViewById(R.id._subsidiarySpinner);
        _productProvider = (Spinner) _myView.findViewById(R.id._productProvider);
        _productName = (EditText) _myView.findViewById(R.id._productName);
        _productDescription = (EditText) _myView.findViewById(R.id._productDescription);
        _productQuantity = (EditText) _myView.findViewById(R.id._productQuantity);
        _yesExempt = (CheckBox) _myView.findViewById(R.id._yesExempt);
        _productPrice = (EditText) _myView.findViewById(R.id._productPrice);
        _productRegister = (Button) _myView.findViewById(R.id._productRegister);
        _productCategory = (Spinner) _myView.findViewById(R.id._productCategory);

        _toSync = getString(R.string.server_url)+"api/product/post@";
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                loadProvider();
                loadSubsidiary();
                loadCategory();
                _subsidiaryAdapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_subsidiaryView);
                _subsidiarySpinner.setAdapter(_subsidiaryAdapter);

                _productCategory.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        _category = _productCategoryList.get(position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });
                _subsidiarySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        _subsidiaryPosition = _subsidiaryID.get(position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                _productProvider.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        try {
                            _providerPosition = _providers.get(position).getInt("P_ID");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                _productRegister.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(final View v) {
                        if (_subsidiaryID.size() == 0) {
                            Snackbar.make(v, "There isn´t any subsidiary available at this point. Try later", Snackbar.LENGTH_LONG).show();
                        }
                        if(_providers.size()==0) {
                            Snackbar.make(v, "There isn´t any providers available at this point. Try later", Snackbar.LENGTH_LONG).show();
                        }
                        if (_productCategoryList.size()==0){
                            Snackbar.make(v,"There isn't any categories available at this point. Try later",Snackbar.LENGTH_LONG).show();
                        }
                        if (_productName.getText().toString().matches("")){
                            _productName.setError("You must provide a product name");
                        }
                        if (_productDescription.getText().toString().matches("")){
                            _productDescription.setError("You must provide a product description");
                        }
                        if (_productQuantity.getText().toString().matches("")){
                            _productQuantity.setError("You must enter the quantity available");
                        }
                        if (_productPrice.getText().toString().matches("")) {
                            _productPrice.setError("You must provide a product price");
                        } else {
                            AlertDialog.Builder _auxWindow = new AlertDialog.Builder(getContext());
                            _auxWindow.setIcon(R.drawable.ic_barcode_24dp);
                            _auxWindow.setTitle("Enter the product barcode");
                            final EditText _barcode = new EditText(_auxWindow.getContext());
                            _barcode.setHint("Write the barcode here");
                            _auxWindow.setView(_barcode);
                            _auxWindow.setPositiveButton("Register", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Integer _exempt = 0;
                                    if (_yesExempt.isChecked())
                                        _exempt = 1;

                                    try{
                                        JSONObject params = new JSONObject();
                                        params.put("PR_ID",_barcode.getText().toString());
                                        params.put("PR_Name",_productName.getText().toString());
                                        params.put("PR_Price",_productPrice.getText().toString());
                                        params.put("PR_Exempt",_exempt);
                                        params.put("PR_Description",_productDescription.getText().toString());
                                        params.put("PR_Quantity",Integer.parseInt(_productQuantity.getText().toString()));
                                        params.put("CA_ID",_category);
                                        params.put("PR_Status","Available");
                                        params.put("P_ID",_providerPosition);
                                        params.put("S_ID",_subsidiaryPosition);
                                        params.put("ID_Seller",_wID);
                                        String _tmp = _toSync+params.toString();
                                        insertProduct(params);
                                        DataSync.getInstance(_connectionManager,_wID,getContext()).get_syncData().add(_tmp);
                                    }catch (JSONException e){
                                        e.printStackTrace();
                                    }

                                }
                            }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.cancel();
                                }
                            });
                            _auxWindow.show();
                        }
                    }
                });
            }
        });
        return _myView;
    }
    public void insertProduct(JSONObject params){
        try{
            String _query = "INSERT INTO PRODUCT VALUES(" + params.getInt("PR_ID") + ",'" +
                    params.getString("PR_Name") + "',"+params.getString("PR_Price")+","+
                    params.getInt("PR_Exempt")+",'"+params.getString("PR_Description")+"',"+params.getInt("PR_Quantity")+ ",'"+params.getString("PR_Status")+"'," +
                    params.getInt("S_ID")+"," +
                    params.getInt("P_ID")+");";
            String _query2 = "INSERT INTO CATEXPRODUCT(CA_ID,PR_ID,CXP_Status) VALUES('" +
                    params.getString("CA_ID")+"'," +
                    params.getInt("PR_ID")+",'Available');";
            _database.insertData(_query);
            _database.insertData(_query2);
        }catch (JSONException e){
            e.printStackTrace();
        }catch (SQLiteException e){
            Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
    private void loadCategory(){
        _productCategoryList = new ArrayList<>();
        String _query = "SELECT * FROM CATEGORY WHERE CA_Status <> 'Deleted';";
        Cursor _cursor = _database.selectData(_query);
        if (_cursor.moveToFirst()){
            do{
                _productCategoryList.add(_cursor.getString(0));
            }while (_cursor.moveToNext());
        }
        _categoryAdapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_productCategoryList);
        _productCategory.setAdapter(_categoryAdapter);
        _categoryAdapter.notifyDataSetChanged();
    }
    private void loadSubsidiary() {
        String query = "SELECT * FROM SUCURSAL";
        Cursor _cursor = _database.selectData(query);

        _subsidiaryID = new ArrayList<>();
        _subsidiaryView = new ArrayList<>();

        if (_cursor.moveToFirst()){
            do{
                Integer _SID = _cursor.getInt(0);
                String _SName = _cursor.getString(1);
                _subsidiaryID.add(_SID);
                _subsidiaryView.add("Sucursal: "+_SName);
            }while (_cursor.moveToNext());
        }
        _subsidiaryAdapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_subsidiaryView);
        _subsidiarySpinner.setAdapter(_subsidiaryAdapter);

    }
    private void loadProvider() {
        String query = "SELECT * FROM PROVIDER WHERE P_Status <> 'Deleted'";
        final Cursor _cursor = _database.selectData(query);
        _providerShow = new ArrayList<>();
        _providers = new ArrayList<>();

        if (_cursor.moveToFirst()) {
            do {
                try {
                    JSONObject params = new JSONObject();
                    params.put("P_ID", _cursor.getInt(0));
                    params.put("P_Name", _cursor.getString(1));
                    params.put("P_LName", _cursor.getString(2));
                    params.put("P_Address", _cursor.getString(3));
                    params.put("P_Date", _cursor.getString(4));
                    _providers.add(params);
                    _providerShow.add(_cursor.getString(1) + " " + _cursor.getString(2));
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } while (_cursor.moveToNext());

            _providerAdapter = new ArrayAdapter<String>(getContext(), R.layout.support_simple_spinner_dropdown_item, _providerShow);
            _productProvider.setAdapter(_providerAdapter);
            _providerAdapter.notifyDataSetChanged();

        }
    }
}
