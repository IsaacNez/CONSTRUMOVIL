package epatec.construmovil;

import android.database.Cursor;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Isaac on 11/6/2016.
 */

public class cl_update extends Fragment {
    View _myView;

    EditText _clientNameupdate;
    EditText _clientLNameupdate;
    TextView _clientIDupdate;
    EditText _clientAddressupdate;
    EditText _clientBDateupdate;
    EditText _clientPhoneupdate;

    Button _registerClientupdate;

    Spinner _spinnerShow;

    DBManager _database;

    List<JSONObject> _clients;
    List<String> _names;
    ArrayAdapter<String> _showAdapter;

    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.cl_update,null);
        _database = new DBManager(getContext());

        _clientNameupdate = (EditText) _myView.findViewById(R.id._clientNameupdate);
        _clientLNameupdate = (EditText) _myView.findViewById(R.id._clientLNameupdate);
        _clientIDupdate = (TextView) _myView.findViewById(R.id._clientIDupdate);
        _clientAddressupdate = (EditText) _myView.findViewById(R.id._clientAddressupdate);
        _clientBDateupdate = (EditText) _myView.findViewById(R.id._clientBDateupdate);
        _clientPhoneupdate = (EditText) _myView.findViewById(R.id._clientPhoneupdate);
        _spinnerShow = (Spinner) _myView.findViewById(R.id._spinnerShow);
        _registerClientupdate = (Button) _myView.findViewById(R.id._registerClientupdate);


        loadAllClients();
        _spinnerShow.setAdapter(_showAdapter);
        _spinnerShow.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(_clients.size() == 0){
                    Snackbar.make(_myView,"There isn´t any client yet!",Snackbar.LENGTH_LONG).show();
                    _clientNameupdate.setVisibility(View.INVISIBLE);
                    _clientLNameupdate.setVisibility(View.INVISIBLE);
                    _clientIDupdate.setVisibility(View.INVISIBLE);
                    _clientAddressupdate.setVisibility(View.INVISIBLE);
                    _clientBDateupdate.setVisibility(View.INVISIBLE);
                    _clientPhoneupdate.setVisibility(View.INVISIBLE);

                }else {
                    try {
                        JSONObject _temp = _clients.get(position);
                        _clientNameupdate.setText(_temp.getString("C_Name"));
                        _clientLNameupdate.setText(_temp.getString("C_LName"));
                        _clientIDupdate.setText("" + _temp.getInt("C_ID"));
                        _clientAddressupdate.setText(_temp.getString("C_Address"));
                        _clientBDateupdate.setText(_temp.getString("C_Date"));
                        _clientPhoneupdate.setText("" + _temp.getInt("C_Phone"));
                    } catch (JSONException e) {
                        Snackbar.make(_myView, "The data is corrupted", Snackbar.LENGTH_LONG).show();
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        _registerClientupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (_clientNameupdate.getText().toString().matches("")| _clientLNameupdate.getText().toString().matches("")|
                        _clientAddressupdate.getText().toString().matches("")|
                _clientBDateupdate.getText().toString().matches("")|
                _clientPhoneupdate.getText().toString().matches("")){
                    Snackbar.make(_myView,"You must complete ALL data",Snackbar.LENGTH_LONG).show();
                }else{
                    String _query = "UPDATE CLIENT SET " +
                            "C_Name='"+_clientNameupdate.getText().toString()+"',"+
                            "C_LName='"+_clientLNameupdate.getText().toString()+"',"+
                            "C_Address='"+_clientAddressupdate.getText().toString()+"',"+
                            "C_Date='"+_clientBDateupdate.getText().toString()+"',"+
                            "C_Phone="+_clientPhoneupdate.getText().toString()+
                            " WHERE C_ID="+_clientIDupdate.getText().toString()+";";
                    _database.updateData(_query);
                    Snackbar.make(_myView,"Your data was successfully updated",Snackbar.LENGTH_LONG).show();
                    loadAllClients();
                    _showAdapter.notifyDataSetChanged();
                }
            }
        });
        return _myView;
    }
    private void loadAllClients(){
        String _query = "SELECT * FROM CLIENT";

        _clients = new ArrayList<>();
        _names = new ArrayList<>();

        Cursor _cursor = _database.selectData(_query);
        if (_cursor.moveToFirst()){
            do{
                try{
                    JSONObject _json = new JSONObject();
                    _json.put("C_ID",_cursor.getInt(0));
                    _json.put("C_Name",_cursor.getString(1));
                    _json.put("C_LName",_cursor.getString(2));
                    _json.put("C_Address",_cursor.getString(3));
                    _json.put("C_Phone",_cursor.getInt(4));
                    _json.put("C_Date",_cursor.getString(5));
                    _clients.add(_json);
                    _names.add(_cursor.getString(1)+" "+_cursor.getString(2));
                }catch (JSONException e){
                    Snackbar.make(_myView,"The data is corrupted",Snackbar.LENGTH_LONG).show();
                }
            }while (_cursor.moveToNext());
        }
        _showAdapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_names);
        _showAdapter.notifyDataSetChanged();

    }
}
