package epatec.construmovil;

import android.app.Activity;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Isaac on 11/7/2016.
 */

public class DBManager{
    private DBHelper _helper;
    private SQLiteDatabase _db;
    private static DBManager _instance = null;
    private Context _context;
    public DBManager(Context context) {
        _helper = new DBHelper(context);


    }

    public void insertData(String _query) throws SQLiteException{
        try {
            synchronized ("lock") {
                if (!Data.getInstance().get_lastinsert().matches(_query)) {
                    _db = _helper.getWritableDatabase();
                    _db.beginTransaction();
                    _db.execSQL(_query);
                    _db.setTransactionSuccessful();
                    _db.endTransaction();
                    System.out.println("LA ORDEN QUE SE ESTÁ HACIENDO ES:" + _query);
                    Data.getInstance().set_lastinsert(_query);
                }
            }
        }catch (SQLiteException e){
            System.out.println("EL ERROR HA SIDO: "+e.getLocalizedMessage()+" USANDO EL QUERY \n "+_query);
        }
    }

    public void deleteData(String _query) throws SQLiteException{
        synchronized ("lock") {
            _db = _helper.getWritableDatabase();
            _db.beginTransaction();
            _db.execSQL(_query);
            _db.setTransactionSuccessful();
            _db.endTransaction();
        }
    }

    public void updateData (String _query){
        synchronized ("lock") {
            _db = _helper.getWritableDatabase();
            _db.beginTransaction();
            _db.execSQL(_query);
            _db.setTransactionSuccessful();
            _db.endTransaction();
        }
    }

    public  Cursor selectData (String _query){
        Cursor _result;
        synchronized ("lock") {
            _db = _helper.getWritableDatabase();
            _db.beginTransaction();
            _result = _db.rawQuery(_query, null);
            _db.setTransactionSuccessful();
            _db.endTransaction();
        }
        return _result;
    }
}
