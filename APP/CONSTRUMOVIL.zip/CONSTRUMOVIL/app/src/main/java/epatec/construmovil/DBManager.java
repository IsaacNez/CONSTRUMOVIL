package epatec.construmovil;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Isaac on 11/7/2016.
 */

public class DBManager {
    private DBHelper _helper;
    private SQLiteDatabase _db;
    public DBManager(Context context) {
        _helper = new DBHelper(context);
        _db = _helper.getWritableDatabase();
    }

    public void insertData(String _query){
        _db.execSQL(_query);
    }

    public void deleteData(String _query){
        _db.execSQL(_query);
    }

    public void updateData (String _query){
        _db.execSQL(_query);
    }

    public Cursor selectData (String _query){
        Cursor _result = _db.rawQuery(_query,null);
        return _result;
    }
}
