package epatec.construmovil;

import android.database.Cursor;
import android.net.ConnectivityManager;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.app.assist.AssistStructure;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/13/2016.
 */

public class ca_update extends Fragment {
    View _myView;

    Spinner _categoryShow;
    EditText _cateUpdate;
    Button _updateButton;

    DBManager _database;
    ConnectivityManager _connectionManager;

    String _toSync = "";
    Integer _wID = 0;

    List<String> _categoryName, _categoryDescription;

    ArrayAdapter<String> _categoryAdapter;

    String _category = "";

    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.ca_update,null);

        _database = new DBManager(getContext());
        _toSync = getString(R.string.server_url)+"api/category/update+";
        _connectionManager = (ConnectivityManager)getContext().getSystemService(CONNECTIVITY_SERVICE);

        _categoryShow = (Spinner) _myView.findViewById(R.id._categoryShow);
        _cateUpdate = (EditText) _myView.findViewById(R.id._cateUpdate);
        _updateButton = (Button) _myView.findViewById(R.id._updateButton);
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                loadCategories();
                _categoryShow.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        _category = _categoryName.get(position);
                        _cateUpdate.setText(_categoryDescription.get(position));
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                _updateButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (_cateUpdate.getText().toString().matches("")){
                            Snackbar.make(v,"You must provide a description for this category",Snackbar.LENGTH_LONG).show();
                        }else{
                            String _query = "UPDATE CATEGORY SET CA_Description='"+_cateUpdate.getText().toString()+"' " +
                                    "WHERE CA_ID='"+_category+"';";
                            try{
                                JSONObject params = new JSONObject();
                                params.put("CA_ID",_category);
                                params.put("CA_Description",_cateUpdate.getText().toString());
                                params.put("ID_Seller",_wID);
                                String _tmp = _toSync+params.toString();
                                _database.updateData(_query);
                                DataSync.getInstance(_connectionManager,_wID).get_syncData().add(_tmp);
                                Snackbar.make(v,"You have successfully updated the data",Snackbar.LENGTH_LONG).show();
                            }catch (JSONException e){
                                e.printStackTrace();
                            }
                        }
                    }
                });

            }
        });
        return _myView;
    }
    private void loadCategories(){
        _categoryName = new ArrayList<>();
        _categoryDescription = new ArrayList<>();
        String _query = "SELECT * FROM CATEGORY";
        Cursor _cursor = _database.selectData(_query);
        if (_cursor.moveToFirst()){
            do{
                _categoryName.add(_cursor.getString(0));
                _categoryDescription.add(_cursor.getString(1));
            }while (_cursor.moveToNext());
        }
        _categoryAdapter = new ArrayAdapter<String>(getContext(),
                R.layout.support_simple_spinner_dropdown_item,_categoryName);
        _categoryShow.setAdapter(_categoryAdapter);
        _categoryAdapter.notifyDataSetChanged();
    }
}
