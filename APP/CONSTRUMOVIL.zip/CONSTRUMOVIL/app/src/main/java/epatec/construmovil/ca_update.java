package epatec.construmovil;

import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.ConnectivityManager;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.app.assist.AssistStructure;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/13/2016.
 */

public class ca_update extends Fragment {
    View _myView;

    Spinner _categoryShow;
    EditText _cateUpdate;
    Button _updateButton;

    DBManager _database;
    ConnectivityManager _connectionManager;

    String _toSync = "";
    Integer _wID = 0;

    List<String> _categoryName, _categoryDescription;

    ArrayAdapter<String> _categoryAdapter;

    String _category = "";

    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.ca_update,null);
        _wID = getArguments().getInt("W_ID",0);
        _database = new DBManager(getContext());
        _toSync = getString(R.string.server_url)+"api/category/update@";
        _connectionManager = (ConnectivityManager)getContext().getSystemService(CONNECTIVITY_SERVICE);

        _categoryShow = (Spinner) _myView.findViewById(R.id._categoryShow);
        _cateUpdate = (EditText) _myView.findViewById(R.id._cateUpdate);
        _updateButton = (Button) _myView.findViewById(R.id._updateButton);
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                loadCategories();
                _categoryShow.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        _category = _categoryName.get(position);
                        _cateUpdate.setText(_categoryDescription.get(position));
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                _updateButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (_cateUpdate.getText().toString().matches("")){
                            Snackbar.make(v,"You must provide a description for this category",Snackbar.LENGTH_LONG).show();
                        }else{

                            try{
                                JSONObject params = new JSONObject();
                                params.put("CA_ID",_category);
                                params.put("CA_Description",_cateUpdate.getText().toString());
                                params.put("CA_Status","Available");
                                params.put("ID_Seller",_wID);
                                update(params);
                                String _tmp = _toSync+params.toString();
                                DataSync.getInstance(_connectionManager,_wID,getContext()).get_syncData().add(_tmp);
                                Snackbar.make(v,"You have successfully updated the data",Snackbar.LENGTH_LONG).show();
                            }catch (JSONException e){
                                e.printStackTrace();
                            }
                        }
                    }
                });

            }
        });
        return _myView;
    }

    /**
     * Actualiza los datos de una categoría considerando
     * que la condición de actualización es la llave primaria
     * @param params
     */
    public void update(JSONObject params){
        try{
            String _query = "UPDATE CATEGORY SET CA_Description='"+params.get("CA_Description")+"' " +
                    "WHERE CA_ID='"+params.getString("CA_ID")+"';";
            _database.updateData(_query);
        }catch (JSONException e){
            e.printStackTrace();
        }catch (SQLiteException e){
            Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Carga la categoría que no han sido eliminadas
     */
    private void loadCategories(){
        _categoryName = new ArrayList<>();
        _categoryDescription = new ArrayList<>();
        String _query = "SELECT * FROM CATEGORY WHERE CA_Status <> 'Deleted'";
        Cursor _cursor = _database.selectData(_query);
        if (_cursor.moveToFirst()){
            do{
                _categoryName.add(_cursor.getString(0));
                _categoryDescription.add(_cursor.getString(1));
            }while (_cursor.moveToNext());
        }
        _categoryAdapter = new ArrayAdapter<String>(getContext(),
                R.layout.support_simple_spinner_dropdown_item,_categoryName);
        _categoryShow.setAdapter(_categoryAdapter);
        _categoryAdapter.notifyDataSetChanged();
    }
}
