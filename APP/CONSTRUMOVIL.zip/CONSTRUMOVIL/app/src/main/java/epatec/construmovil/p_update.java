package epatec.construmovil;

import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.ConnectivityManager;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/13/2016.
 */

public class p_update extends Fragment {
    View _myView;

    DBManager _database;

    Spinner _providerShow;

    TextView _providerID;

    EditText _providerName;
    EditText _providerLName;
    EditText _providerAddress;
    EditText _providerBDate;

    Button _providerUpdate;

    ArrayAdapter<String> _showProviders;

    Integer _ID,_wID = 0;

    List<String> _providersNames;
    List<JSONObject> _providers;

    String _toSync="";

    ConnectivityManager _connectionManager;
    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.p_update, null);
        _database = new DBManager(getContext());
        _connectionManager = (ConnectivityManager) getContext().getSystemService(CONNECTIVITY_SERVICE);
        _toSync = getString(R.string.server_url)+"api/provider/update@";
        _providerShow = (Spinner) _myView.findViewById(R.id._providerShowUpdate);
        _providerID = (TextView) _myView.findViewById(R.id._providerID);
        _providerName = (EditText) _myView.findViewById(R.id._providerName);
        _providerLName = (EditText) _myView.findViewById(R.id._providerLName);
        _providerAddress = (EditText) _myView.findViewById(R.id._providerAddress);
        _providerBDate = (EditText) _myView.findViewById(R.id._providerBDate);

        _providerUpdate = (Button) _myView.findViewById(R.id._providerUpdate);
        loadAllProviders();
        _providerShow.setAdapter(_showProviders);
        new Thread(new Runnable() {
            @Override
            public void run() {
                _providerShow.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        JSONObject _tmp = _providers.get(position);
                        try {
                            _ID = _tmp.getInt("P_ID");
                            _providerID.setText("" + _ID);
                            _providerName.setText(_tmp.getString("P_Name"));

                            _providerLName.setText(_tmp.getString("P_LName"));
                            _providerAddress.setText(_tmp.getString("P_Address"));
                            _providerBDate.setText(_tmp.getString("P_Date"));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                _providerUpdate.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (_providerName.getText().toString().matches("") | _providerLName.getText().toString().matches("")
                                | _providerAddress.getText().toString().matches("") | !_providerBDate.getText().toString().matches("^\\d{4}\\-(0?[1-9]|1[012])\\-(0?[1-9]|[12][0-9]|3[01])$")){
                            Snackbar.make(v, "You must provide valid information, Please check again",Snackbar.LENGTH_LONG).show();
                        }else {
                            try {
                                JSONObject params = new JSONObject();
                                params.put("P_ID",_providerID.getText().toString());
                                params.put("P_Name",_providerName.getText().toString());
                                params.put("P_LName",_providerLName.getText().toString());
                                params.put("P_Address",_providerAddress.getText().toString());
                                params.put("P_Date",_providerBDate.getText().toString());
                                params.put("P_Status","Available");
                                params.put("ID_Seller",_wID);
                                String _tmp = _toSync+params.toString();
                                updateProvider(params);
                                Snackbar.make(v, "You have succesfully updated the data",Snackbar.LENGTH_LONG).show();
                                DataSync.getInstance(_connectionManager,_wID,getContext()).get_syncData().add(_tmp);
                                synchronized (_showProviders) {
                                    _providersNames = new ArrayList<String>();
                                    loadAllProviders();
                                    _showProviders = new ArrayAdapter<String>(getContext(), R.layout.support_simple_spinner_dropdown_item, _providersNames);
                                    _showProviders.notifyDataSetChanged();
                                }
                                //_showProviders.notify();

                            }catch (JSONException e){
                                e.printStackTrace();
                            }
                        }
                    }
                });
            }
        }).start();

        return _myView;
    }
    public void updateProvider(JSONObject params){
        try{

            String _query = "UPDATE PROVIDER SET "+
                    "P_Name ='"+params.getString("P_Name")+"',"+
                    "P_LName='"+params.get("P_LName")+"',"+
                    "P_Address='"+params.getString("P_Address")+"',"+
                    "P_Date='"+params.getString("P_Date")+"' WHERE" +
                    " P_ID="+params.getInt("P_ID")+";";
            _database.updateData(_query);
        }catch (JSONException e){
            e.printStackTrace();
        }catch (SQLiteException e){
            Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
    private void loadAllProviders(){
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String query = "SELECT * FROM PROVIDER WHERE P_Status <> 'Deleted'";
                _providersNames = new ArrayList<String>();
                _providers = new ArrayList<JSONObject>();

                Cursor _cursor = _database.selectData(query);
                if(_cursor.moveToFirst()){
                    do {
                        try {
                            JSONObject params = new JSONObject();
                            params.put("P_ID", _cursor.getInt(0));
                            params.put("P_Name", _cursor.getString(1));
                            params.put("P_LName", _cursor.getString(2));
                            params.put("P_Address", _cursor.getString(3));
                            params.put("P_Date", _cursor.getString(4));
                            _providers.add(params);
                            _providersNames.add(_cursor.getString(1) + " " + _cursor.getString(2));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }while(_cursor.moveToNext());
                }
                _showProviders = new ArrayAdapter<String>(getContext(), R.layout.support_simple_spinner_dropdown_item,_providersNames);
                _showProviders.notifyDataSetChanged();

            }
        });
    }
}
