package epatec.construmovil;

import android.database.sqlite.SQLiteException;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/6/2016.
 */

public class cl_create extends Fragment {
    View _myView;

    EditText _clientName;
    EditText _clientLName;
    EditText _clientID;
    EditText _clientAddress;
    EditText _clientBDate;
    EditText _clientPhone;

    Button _registerClient;

    DBManager _database;

    Integer _wID =0;

    String _queryClient = "INSERT INTO CLIENT VALUES(";

    ConnectivityManager _connectionManager;
    String _toSync = "";
    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.cl_create,null);
        _database = new DBManager(getContext());
        _wID = getArguments().getInt("W_ID",0);
        _connectionManager = (ConnectivityManager)getContext().getSystemService(CONNECTIVITY_SERVICE);
        _toSync = getString(R.string.server_url)+"api/client/post@";
        _clientName = (EditText) _myView.findViewById(R.id._clientName);
        _clientLName = (EditText) _myView.findViewById(R.id._clientLName);
        _clientID = (EditText) _myView.findViewById(R.id._clientID);
        _clientAddress = (EditText) _myView.findViewById(R.id._clientAddress);
        _clientBDate = (EditText) _myView.findViewById(R.id._clientBDate);
        _clientPhone = (EditText) _myView.findViewById(R.id._clientPhone);

        _registerClient = (Button) _myView.findViewById(R.id._registerClient);

        _registerClient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (_clientLName.getText().toString().matches("")| _clientLName.getText().toString().matches("")|_clientID.getText().toString().matches("")|
                        _clientAddress.getText().toString().matches("")|_clientBDate.getText().toString().matches("")|_clientPhone.getText().toString().matches(""))
                    Snackbar.make(v,"You must complete all the information",Snackbar.LENGTH_LONG).show();
                else{
                    try{
                        JSONObject object = new JSONObject();
                        object.put("C_ID",_clientID.getText().toString());
                        object.put("C_Name",_clientName.getText().toString());
                        object.put("C_LName",_clientLName.getText().toString());
                        object.put("C_Address",_clientAddress.getText().toString());
                        object.put("C_Date",_clientBDate.getText().toString());
                        object.put("C_Phone",_clientPhone.getText().toString());
                        object.put("C_Penalization",0);
                        object.put("C_Status","Available");
                        object.put("ID_Seller",_wID);
                        insertClient(object);
                        String _temp = _toSync+ object.toString();
                        DataSync.getInstance(_connectionManager,_wID).get_syncData().add(_temp);
                        Snackbar.make(v,"Data successufully inserted",Snackbar.LENGTH_LONG).show();
                    }catch (JSONException e) {
                        e.printStackTrace();
                    }
                    _clientName.setText("");
                    _clientLName.setText("");
                    _clientID .setText("");
                    _clientAddress .setText("");
                    _clientBDate.setText("");
                    _clientPhone.setText("");
                }
            }
        });
        return _myView;
    }

    public void insertClient(JSONObject params){
        try{
            String _query = _queryClient+params.getInt("C_ID")+",'"+params.getString("C_Name")
                    + "','"+params.getString("C_LName")+"','"+params.getString("C_Address")+
                    "',"+params.getInt("C_Phone")+",'"+params.getString("C_Date")+"',"
                    +params.getInt("C_Penalization")+",'Available');";
            _database.insertData(_query);
        }catch (JSONException e){
            e.printStackTrace();
        }catch (SQLiteException e){
            Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }



}
