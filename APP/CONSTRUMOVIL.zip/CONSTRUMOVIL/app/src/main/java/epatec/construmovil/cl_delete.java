package epatec.construmovil;

import android.content.DialogInterface;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.support.annotation.StringDef;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/6/2016.
 */

public class cl_delete extends Fragment {
    View _myView;

    List<String> _optionsdelete = new ArrayList<>();

    Spinner _deleteoptions;
    Button _searchclient;
    EditText _searchparams;

    ArrayAdapter<String> _deleteoptionsadapter;

    String _paramSelected = "";

    ListView _clientsview;

    DBManager _database;
    List<JSONObject> _clients;
    List<String> _names;
    Integer _clientID =0;
    Integer _position=0;
    ArrayAdapter<String> _clientsAdapter;
    ConnectivityManager _connectionManager;
    String _toSend = "";
    Integer _wID=0;
    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.cl_delete,null);
        startData();
        _toSend = getString(R.string.server_url)+"api/client/delete/";
        _connectionManager = (ConnectivityManager)getContext().getSystemService(CONNECTIVITY_SERVICE);

        _database = new DBManager(getContext());
        _searchclient = (Button) _myView.findViewById(R.id._searchclient);
        _searchparams = (EditText) _myView.findViewById(R.id._searchparams);
        _clientsview = (ListView) _myView.findViewById(R.id._clientsview);
        _deleteoptions = (Spinner) _myView.findViewById(R.id._deleteoptions);
        _deleteoptionsadapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_optionsdelete);
        _deleteoptions.setAdapter(_deleteoptionsadapter);
        new Thread(new Runnable() {
            @Override
            public void run() {
                _deleteoptions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                        choose(position);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });

                _searchclient.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (_searchparams.getText().toString().matches(""))
                            Snackbar.make(v,"Your must provide a search parameter", Snackbar.LENGTH_LONG).show();
                        else {
                            String SQLQuery = "SELECT * FROM CLIENT WHERE " + _paramSelected + " LIKE '%" + _searchparams.getText().toString() + "%';";
                            Cursor _result = _database.selectData(SQLQuery);
                            System.out.println("SE ESTÁ HACIENDO EL QUERY "+SQLQuery+_result.getCount());
                            loadData(_result);
                        }
                    }
                });

                _clientsview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        _position = position;
                        JSONObject _js = _clients.get(position);
                        try {
                            _clientID = _js.getInt("C_ID");
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                        AlertDialog.Builder _alert = new AlertDialog.Builder(getContext());
                        _alert.setIcon(R.drawable.ic_delete_black_24dp);
                        _alert.setTitle("Delete this client?");
                        _alert.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String _query = "DELETE FROM CLIENT WHERE C_ID="+_clientID;
                                _database.deleteData(_query);
                                String _temp = _toSend+"C_ID,ID_Seller/"+_clientID+","+_wID;
                                DataSync.getInstance(_connectionManager,_wID).get_syncData().add(_temp);
                                List<String> _tmp = new ArrayList<String>();
                                for(int i = 0; i < _names.size(); i++){
                                    if(i != _position)
                                        _tmp.add(_names.get(i));

                                }
                                _names = _tmp;
                                _clientsAdapter.notifyDataSetChanged();
                            }
                        })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                });
                        _alert.show();
                    }
                });
            }
        }).start();





        return _myView;
    }
    public void startData(){
        _optionsdelete.add("Name");
        _optionsdelete.add("Last Name");
        _optionsdelete.add("ID");
        _optionsdelete.add("Phone");
        _optionsdelete.add("Birth date");
        _optionsdelete.add("Address");
    }

    private void choose(int position){
        switch (position){
            case 0:
                _paramSelected = "C_Name";
                break;
            case 1:
                _paramSelected = "C_LName";
                break;
            case 2:
                _paramSelected = "C_ID";
                break;
            case 3:
                _paramSelected = "C_Phone";
                break;
            case 4:
                _paramSelected = "C_Date";
                break;
            case 5:
                _paramSelected = "C_Address";
                break;
        }
    }
    public void loadData(final Cursor _cursor){
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                _clients = new ArrayList<>();
                _names = new ArrayList<>();
                if (_cursor.moveToFirst()){
                    do{
                        try{
                            JSONObject _json = new JSONObject();
                            _json.put("C_ID",_cursor.getInt(0));
                            _json.put("C_Name",_cursor.getString(1));
                            _json.put("C_LName",_cursor.getString(2));
                            _json.put("C_Address",_cursor.getString(3));
                            _json.put("C_Phone",_cursor.getInt(4));
                            _json.put("C_Date",_cursor.getString(5));
                            _clients.add(_json);
                            _names.add(_cursor.getString(1)+" "+_cursor.getString(2));
                        }catch (JSONException e){
                            Snackbar.make(_myView,"The data is corrupted",Snackbar.LENGTH_LONG).show();
                        }
                    }while (_cursor.moveToNext());
                }
                _clientsAdapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_names);
                _clientsview.setAdapter(_clientsAdapter);
                _clientsAdapter.notifyDataSetChanged();
            }
        });

    }
}
