package epatec.construmovil;

import android.support.annotation.StringDef;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Isaac on 11/6/2016.
 */

public class cl_delete extends Fragment {
    View _myView;

    List<String> _optionsdelete = new ArrayList<>();

    Spinner _deleteoptions;
    Button _searchclient;
    EditText _searchparams;

    ArrayAdapter<String> _deleteoptionsadapter;

    String _paramSelected = "";

    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.cl_delete,null);
        startData();

        _searchclient = (Button) _myView.findViewById(R.id._searchclient);
        _searchparams = (EditText) _myView.findViewById(R.id._searchparams);

        _deleteoptions = (Spinner) _myView.findViewById(R.id._deleteoptions);
        _deleteoptionsadapter = new ArrayAdapter<String>(getContext(),R.layout.support_simple_spinner_dropdown_item,_optionsdelete);
        _deleteoptions.setAdapter(_deleteoptionsadapter);

        _deleteoptions.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                choose(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        _searchclient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (_searchparams.getText().toString().matches(""))
                    Snackbar.make(v,"Your must provide a search parameter", Snackbar.LENGTH_LONG).show();
                else {
                    String SQLQuery = "SELECT * FROM CLIENT WHERE " + _paramSelected + " LIKE '%" + _searchparams.getText().toString() + "%';";
                }
            }
        });
        return _myView;
    }
    public void startData(){
        _optionsdelete.add("Name");
        _optionsdelete.add("Last Name");
        _optionsdelete.add("ID");
        _optionsdelete.add("Phone");
        _optionsdelete.add("Birth date");
        _optionsdelete.add("Address");
    }

    private void choose(int position){
        switch (position){
            case 0:
                _paramSelected = "C_Name";
                break;
            case 1:
                _paramSelected = "C_LName";
                break;
            case 2:
                _paramSelected = "C_ID";
                break;
            case 3:
                _paramSelected = "C_Phone";
                break;
            case 4:
                _paramSelected = "C_Date";
                break;
            case 5:
                _paramSelected = "C_Address";
                break;
        }
    }
}
