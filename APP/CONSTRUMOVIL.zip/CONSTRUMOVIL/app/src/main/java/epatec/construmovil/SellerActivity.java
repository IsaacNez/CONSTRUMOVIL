package epatec.construmovil;

import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;

public class SellerActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    String _sellerName = "Juan";
    Toolbar toolbar;
    ConnectivityManager _connectionManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller);
        toolbar = (Toolbar) findViewById(R.id._activityseller);
        toolbar.setTitle("CONSTRUMOVIL APP");
        setSupportActionBar(toolbar);

        _connectionManager = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        DataSync.getInstance(_connectionManager,1234);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        NavigationView nav = (NavigationView) findViewById(R.id.nav_view);
        Menu nav_me = nav.getMenu();
        nav_me.findItem(R.id.nav_comunicate).setVisible(false);
        nav_me.findItem(R.id.nav_product_op).setVisible(false);
        nav_me.findItem(R.id.nav_order_op).setVisible(false);
        nav_me.findItem(R.id.nav_provider_op).setVisible(false);
        nav_me.findItem(R.id.nav_category_op).setVisible(false);
        getMenuInflater().inflate(R.menu.seller, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        NavigationView nav = (NavigationView) findViewById(R.id.nav_view);
        Menu nav_me = nav.getMenu();

        int id = item.getItemId();

        FragmentManager _fragmentManager = getSupportFragmentManager();

        if (id == R.id.nav_client) {
            nav_me.findItem(R.id.nav_comunicate).setVisible(true);
            nav_me.findItem(R.id.nav_product_op).setVisible(false);
            nav_me.findItem(R.id.nav_order_op).setVisible(false);
            nav_me.findItem(R.id.nav_provider_op).setVisible(false);
            nav_me.findItem(R.id.nav_category_op).setVisible(false);
            // Handle the camera action
        } else if (id == R.id.nav_products) {
            nav_me.findItem(R.id.nav_comunicate).setVisible(false);
            nav_me.findItem(R.id.nav_product_op).setVisible(true);
            nav_me.findItem(R.id.nav_order_op).setVisible(false);
            nav_me.findItem(R.id.nav_provider_op).setVisible(false);
            nav_me.findItem(R.id.nav_category_op).setVisible(false);

        } else if (id == R.id.nav_orders) {
            nav_me.findItem(R.id.nav_comunicate).setVisible(false);
            nav_me.findItem(R.id.nav_product_op).setVisible(false);
            nav_me.findItem(R.id.nav_order_op).setVisible(true);
            nav_me.findItem(R.id.nav_provider_op).setVisible(false);
            nav_me.findItem(R.id.nav_category_op).setVisible(false);

        }else if (id == R.id.nav_provider) {
            nav_me.findItem(R.id.nav_comunicate).setVisible(false);
            nav_me.findItem(R.id.nav_product_op).setVisible(false);
            nav_me.findItem(R.id.nav_order_op).setVisible(false);
            nav_me.findItem(R.id.nav_provider_op).setVisible(true);
            nav_me.findItem(R.id.nav_category_op).setVisible(false);

        }else if (id == R.id.nav_category){
            nav_me.findItem(R.id.nav_comunicate).setVisible(false);
            nav_me.findItem(R.id.nav_product_op).setVisible(false);
            nav_me.findItem(R.id.nav_order_op).setVisible(false);
            nav_me.findItem(R.id.nav_provider_op).setVisible(false);
            nav_me.findItem(R.id.nav_category_op).setVisible(true);

        }else if (id == R.id.nav_seller) {
            nav_me.findItem(R.id.nav_comunicate).setVisible(false);
            nav_me.findItem(R.id.nav_product_op).setVisible(false);
            nav_me.findItem(R.id.nav_order_op).setVisible(false);
            nav_me.findItem(R.id.nav_provider_op).setVisible(false);
            nav_me.findItem(R.id.nav_category_op).setVisible(false);
            s_update s_update = new s_update();
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,s_update)
                    .commit();
            toolbar.setTitle("Update Seller");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.cl_create){
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,new cl_create())
                    .commit();
            toolbar.setTitle("Create client");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.cl_update){
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,new cl_update())
                    .commit();
            toolbar.setTitle("Update client");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.cl_delete){
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,new cl_delete())
                    .commit();
            toolbar.setTitle("Delete client");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.pr_create){
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,new pr_create())
                    .commit();
            toolbar.setTitle("Create product");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.pr_update){
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller, new pr_update())
                    .commit();
            toolbar.setTitle("Update product");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.pr_delete){
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller, new pr_delete())
                    .commit();
            toolbar.setTitle("Delete product");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.or_create){
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller, new or_create())
                    .commit();
            toolbar.setTitle("Create order");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.or_delete){
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller, new or_delete())
                    .commit();
            toolbar.setTitle("Delete order");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.p_create){
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,new p_create())
                    .commit();
            toolbar.setTitle("Create provider");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.p_update){
            p_update _p = new p_update();
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,_p)
                    .commit();
            toolbar.setTitle("Update provider");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.p_delete){
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,new p_delete())
                    .commit();
            toolbar.setTitle("Delete provider");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.ca_create){
            ca_create _cacreate = new ca_create();
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,_cacreate)
                    .commit();
            toolbar.setTitle("Create Category");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.ca_update){
            ca_update ca_update = new ca_update();
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,ca_update)
                    .commit();
            toolbar.setTitle("Update Category");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.ca_delete){
            ca_delete ca_delete = new ca_delete();
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,ca_delete)
                    .commit();
            toolbar.setTitle("Delete Category");
            drawer.closeDrawer(GravityCompat.START);

        }



        return true;
    }
}
