package epatec.construmovil;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Looper;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.io.UnsupportedEncodingException;

public class SellerActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    String _sellerName = "";
    Integer _wID = 0;
    Toolbar toolbar;
    ConnectivityManager _connectionManager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller);
        toolbar = (Toolbar) findViewById(R.id._activityseller);
        toolbar.setTitle("CONSTRUMOVIL APP");
        setSupportActionBar(toolbar);
        Intent _newIntent = getIntent();
        _sellerName = _newIntent.getStringExtra("W_Name");
        _wID = _newIntent.getIntExtra("W_ID",0);

        _connectionManager = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);



        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        NavigationView nav = (NavigationView) findViewById(R.id.nav_view);
        Menu nav_me = nav.getMenu();
        nav_me.findItem(R.id.nav_comunicate).setVisible(false);
        nav_me.findItem(R.id.nav_product_op).setVisible(false);
        nav_me.findItem(R.id.nav_order_op).setVisible(false);
        nav_me.findItem(R.id.nav_provider_op).setVisible(false);
        nav_me.findItem(R.id.nav_category_op).setVisible(false);
        TextView username = (TextView) findViewById(R.id.Name_User);
        TextView emailuser = (TextView) findViewById(R.id.textView);
        username.setText(_sellerName);
        emailuser.setText("Seller ID: "+_wID);
        getMenuInflater().inflate(R.menu.seller, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Dependiendo del boton que presione, así será la vista que le aparezca
     * @param item
     * @return
     */
    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        final DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        NavigationView nav = (NavigationView) findViewById(R.id.nav_view);
        Menu nav_me = nav.getMenu();

        int id = item.getItemId();

        FragmentManager _fragmentManager = getSupportFragmentManager();
        Bundle extradata = new Bundle();
        extradata.putString("W_Name",_sellerName);
        extradata.putInt("W_ID",_wID);

        if (id == R.id.nav_client) {
            nav_me.findItem(R.id.nav_comunicate).setVisible(true);
            nav_me.findItem(R.id.nav_product_op).setVisible(false);
            nav_me.findItem(R.id.nav_order_op).setVisible(false);
            nav_me.findItem(R.id.nav_provider_op).setVisible(false);
            nav_me.findItem(R.id.nav_category_op).setVisible(false);
            // Handle the camera action
        } else if (id == R.id.nav_products) {
            nav_me.findItem(R.id.nav_comunicate).setVisible(false);
            nav_me.findItem(R.id.nav_product_op).setVisible(true);
            nav_me.findItem(R.id.nav_order_op).setVisible(false);
            nav_me.findItem(R.id.nav_provider_op).setVisible(false);
            nav_me.findItem(R.id.nav_category_op).setVisible(false);

        } else if (id == R.id.nav_orders) {
            nav_me.findItem(R.id.nav_comunicate).setVisible(false);
            nav_me.findItem(R.id.nav_product_op).setVisible(false);
            nav_me.findItem(R.id.nav_order_op).setVisible(true);
            nav_me.findItem(R.id.nav_provider_op).setVisible(false);
            nav_me.findItem(R.id.nav_category_op).setVisible(false);

        }else if (id == R.id.nav_provider) {
            nav_me.findItem(R.id.nav_comunicate).setVisible(false);
            nav_me.findItem(R.id.nav_product_op).setVisible(false);
            nav_me.findItem(R.id.nav_order_op).setVisible(false);
            nav_me.findItem(R.id.nav_provider_op).setVisible(true);
            nav_me.findItem(R.id.nav_category_op).setVisible(false);

        }else if (id == R.id.nav_category){
            nav_me.findItem(R.id.nav_comunicate).setVisible(false);
            nav_me.findItem(R.id.nav_product_op).setVisible(false);
            nav_me.findItem(R.id.nav_order_op).setVisible(false);
            nav_me.findItem(R.id.nav_provider_op).setVisible(false);
            nav_me.findItem(R.id.nav_category_op).setVisible(true);

        }else if (id == R.id.nav_seller) {
            nav_me.findItem(R.id.nav_comunicate).setVisible(false);
            nav_me.findItem(R.id.nav_product_op).setVisible(false);
            nav_me.findItem(R.id.nav_order_op).setVisible(false);
            nav_me.findItem(R.id.nav_provider_op).setVisible(false);
            nav_me.findItem(R.id.nav_category_op).setVisible(false);
            s_update s_update = new s_update();
            s_update.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,s_update)
                    .commit();
            toolbar.setTitle("Update Seller");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.cl_create){
            cl_create cl_create = new cl_create();
            cl_create.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller, cl_create)
                    .commit();
            toolbar.setTitle("Create client");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.cl_update){
            cl_update cl_update = new cl_update();
            cl_update.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,cl_update)
                    .commit();
            toolbar.setTitle("Update client");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.cl_delete){
            cl_delete cl_delete = new cl_delete();
            cl_delete.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,cl_delete)
                    .commit();
            toolbar.setTitle("Delete client");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.pr_create){
            pr_create pr_create = new pr_create();
            pr_create.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,pr_create)
                    .commit();
            toolbar.setTitle("Create product");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.pr_update){
            pr_update pr_update = new pr_update();
            pr_update.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,  pr_update)
                    .commit();
            toolbar.setTitle("Update product");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.pr_delete){
            pr_delete pr_delete = new pr_delete();
            pr_delete.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller, pr_delete)
                    .commit();
            toolbar.setTitle("Delete product");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.or_create){
            or_create or_create = new or_create();
            or_create.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,or_create)
                    .commit();
            toolbar.setTitle("Create order");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.or_delete){
            or_delete or_delete = new or_delete();
            or_delete.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller, or_delete)
                    .commit();
            toolbar.setTitle("Delete order");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.p_create){
            p_create p_create = new p_create();
            p_create.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,p_create)
                    .commit();
            toolbar.setTitle("Create provider");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.p_update){
            p_update _p = new p_update();
            _p.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,_p)
                    .commit();
            toolbar.setTitle("Update provider");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.p_delete){
            p_delete p_delete = new p_delete();
            p_delete.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,p_delete)
                    .commit();
            toolbar.setTitle("Delete provider");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.ca_create){
            ca_create _cacreate = new ca_create();
            _cacreate.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,_cacreate)
                    .commit();
            toolbar.setTitle("Create Category");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.ca_update){
            ca_update ca_update = new ca_update();
            ca_update.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,ca_update)
                    .commit();
            toolbar.setTitle("Update Category");
            drawer.closeDrawer(GravityCompat.START);

        }else if (id == R.id.ca_delete){
            ca_delete ca_delete = new ca_delete();
            ca_delete.setArguments(extradata);
            _fragmentManager.beginTransaction()
                    .replace(R.id.content_seller,ca_delete)
                    .commit();
            toolbar.setTitle("Delete Category");
            drawer.closeDrawer(GravityCompat.START);

        }
        /**
         * A la hora de hacer una sincronización matutina, ejecuta inmediantamente el thread
         */
        else if (id == R.id.nav_early_sync){
            //Looper.prepare();
            new Thread(new Runnable() {
                @Override
                public void run() {
                    DataSync.getInstance(_connectionManager,_wID,getApplicationContext()).AskInfo();
                    System.out.println("SYNC....1");
                    drawer.closeDrawer(GravityCompat.START);
                }
            }).start();

            /**
             * Ejecuta la accion de sincronización vespertina al momento que se acciona el botón
             */
        }else if (id == R.id.nav_late_sync){

            try {
                DataSync.getInstance(_connectionManager,_wID,getApplicationContext()).Sync();
                System.out.println("SYNC....12");
                drawer.closeDrawer(GravityCompat.START);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

        }

        return true;
    }
}
