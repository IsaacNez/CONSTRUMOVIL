package epatec.construmovil;

import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteException;
import android.net.ConnectivityManager;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.CONNECTIVITY_SERVICE;

/**
 * Created by Isaac on 11/13/2016.
 */

public class ca_delete extends Fragment {
    View _myView;

    ListView _cateDelete;

    DBManager _database;
    ConnectivityManager _connectionManager;

    String _toSync = "";
    Integer _wID = 0;

    List<String> _categoryName;

    ArrayAdapter<String> _categoryAdapter;

    /**
     * Called to have the fragment instantiate its user interface view.
     * This is optional, and non-graphical fragments can return null (which
     * is the default implementation).  This will be called between
     * {@link #onCreate(Bundle)} and {@link #onActivityCreated(Bundle)}.
     * <p>
     * <p>If you return a View from here, you will later be called in
     * {@link #onDestroyView} when the view is being released.
     *
     * @param inflater           The LayoutInflater object that can be used to inflate
     *                           any views in the fragment,
     * @param container          If non-null, this is the parent view that the fragment's
     *                           UI should be attached to.  The fragment should not add the view itself,
     *                           but this can be used to generate the LayoutParams of the view.
     * @param savedInstanceState If non-null, this fragment is being re-constructed
     *                           from a previous saved state as given here.
     * @return Return the View for the fragment's UI, or null.
     */
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        _myView = inflater.inflate(R.layout.ca_delete,null);
        _wID = getArguments().getInt("W_ID",0);
        _database = new DBManager(getContext());
        _toSync = getString(R.string.server_url)+"api/category/delete/CA_ID,ID_Seller/";
        _connectionManager = (ConnectivityManager)getContext().getSystemService(CONNECTIVITY_SERVICE);

        _cateDelete = (ListView) _myView.findViewById(R.id._cateDelete);
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                loadCategory();
                _cateDelete.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, final int position, long id) {
                        AlertDialog.Builder _aux = new AlertDialog.Builder(getContext());
                        _aux.setTitle("Erase this category?");
                        _aux.setIcon(R.drawable.ic_delete_black_24dp);
                        _aux.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String _cateName = _categoryName.get(position);
                                delete(_cateName);
                                String _tmp = _toSync+_cateName+","+_wID;
                                DataSync.getInstance(_connectionManager,_wID,getContext()).get_syncData().add(_tmp);
                            }
                        })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.cancel();
                                    }
                                }).show();
                    }
                });
            }
        });

        return _myView;
    }
    public void delete(String _cateName){
        String _query1 = "SELECT PR_ID FROM CATEXPRODUCT WHERE CA_ID='"+_cateName+"';";
        Cursor _cursor = _database.selectData(_query1);
        if (_cursor.moveToFirst()){
            do{
                String _query2 = "UPDATE PRODUCT SET PR_Status='Deleted' WHERE PR_ID="+_cursor.getInt(0);
                _database.deleteData(_query2);
            }while (_cursor.moveToNext());
        }
        String _query3 = "UPDATE CATEXPRODUCT SET CXP_Status='Deleted' WHERE CA_ID='"+_cateName+"';";
        String _query4 = "UPDATE CATEGORY SET CA_Status='Deleted' WHERE CA_ID='"+_cateName+"';";
        try {
            _database.deleteData(_query3);
            _database.deleteData(_query4);
        }catch (SQLiteException e){
            Toast.makeText(getContext(),e.getMessage(),Toast.LENGTH_LONG).show();
        }
    }
    private void loadCategory(){
        _categoryName = new ArrayList<>();
        String _query = "SELECT * FROM CATEGORY WHERE CA_Status <> 'Deleted'";
        Cursor _cursor = _database.selectData(_query);
        if (_cursor.moveToFirst()){
            do {
                _categoryName.add(_cursor.getString(0));
            }while (_cursor.moveToNext());
        }
        _categoryAdapter = new ArrayAdapter<String>(getContext(),
                android.R.layout.simple_list_item_1,_categoryName);
        _cateDelete.setAdapter(_categoryAdapter);
        _categoryAdapter.notifyDataSetChanged();

    }
}
